# Chinook Data Engineering ETL

A data engineering class project using the Chinook music database. It moves data from SQL Server to PostgreSQL and ClickHouse, keeps the data updated with CDC, and displays results in Grafana. Airflow runs the pipelines automatically.

## Tools

SQL Server, PostgreSQL, ClickHouse, Python, Apache Airflow, Grafana, Docker and WSL2 Ubuntu.

## How to run

You need WSL2 Ubuntu, Docker Engine with Docker Compose, Python 3, curl, and enough memory and disk space for the databases (around 8 GB RAM and 15 GB free storage recommended).

Extract this project somewhere inside your Ubuntu home folder, open a terminal in the `chinook-etl` folder, and run:

```bash
bash install.sh
```

The installer sets up the databases, loads the sample data once, and starts Airflow and Grafana. It can be rerun without deleting existing data. The first installation needs an internet connection to download Docker images and Python packages.

For a quick check:

```bash
bash verify.sh
bash status.sh
```

Open Airflow at **http://localhost:8080** and Grafana at **http://localhost:3000**. Both use the username `admin`. To find the generated passwords locally, run:

```bash
bash secrets-help.sh
```

## What it does

- Loads the Chinook tables from SQL Server into PostgreSQL staging and a ClickHouse data warehouse.
- Uses SQL Server CDC to pick up changes and process them every five minutes with Airflow.
- Updates a PostgreSQL reporting copy for the two Grafana dashboards.
- Keeps data in Docker volumes so normal restarts do not erase it.

## Notes

This is for local learning and demonstration, not a production deployment. SQL Server Developer edition is for non-production use.

The project creates a private `.env` file with passwords. **Never upload `.env` or backups to GitHub.** Do not run `docker compose down -v` or `docker volume prune` because those commands can permanently delete the saved data.

For a cold backup, run `bash backup.sh /path/to/a/private/folder`. Restoring a backup should be done on a separate, stopped installation, not over your current project.
