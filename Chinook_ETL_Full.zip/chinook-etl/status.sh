#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
docker compose ps
printf '\n==> DAG state\n'
docker compose exec -T chinook-airflow airflow dags list 2>/dev/null || true
