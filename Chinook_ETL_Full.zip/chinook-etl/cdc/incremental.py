#!/usr/bin/env python3
"""Chinook CDC: SQL Server CDC -> Postgres staging -> ClickHouse SCD1/2.

Uses the Chinook staging and warehouse schemas. A transaction LSN is processed
atomically in PostgreSQL, with idempotent ClickHouse revisions across retries.
Run one copy at a time. No source data is changed by this program.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import clickhouse_connect
import pymssql
import psycopg2
from psycopg2 import sql
from psycopg2.extras import Json

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'full_load'))
from full_load import (SOURCE, read_env, cfg, records, stage_frames, py, surrogate,
                       geo_key, date_key)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger('chinook.incremental')
PK = {key: (('playlistid', 'trackid') if key == 'playlisttrack' else
            ('invoicelineid',) if key == 'invoiceline' else
            (key + 'id',)) for key in SOURCE.values()}
DIM_TABLES = ('DimGeography', 'DimEmployee', 'DimAlbum', 'DimCustomer',
              'DimTrack', 'DimPlaylist', 'DimPlaylistTrack', 'FactInvoice')


def lsn_bytes(value):
    if isinstance(value, memoryview):
        value = value.tobytes()
    if not isinstance(value, (bytes, bytearray)):
        raise ValueError(f'Invalid CDC LSN {value!r}')
    return bytes(value)


def serializable(v):
    v = py(v)
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, Decimal):
        return str(v)
    if isinstance(v, bytes):
        return v.hex()
    return v


def ensure_completed_full_load(pg, ch):
    with pg.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM etl.pipeline_run WHERE load_kind='full' AND state='completed'")
        if cur.fetchone()[0] != 1:
            raise RuntimeError('Exactly one successful initial full load is required')
        cur.execute('SELECT capture_instance, last_lsn FROM etl.cdc_checkpoint')
        ckpt = {a: lsn_bytes(b) for a,b in cur.fetchall()}
    exp = {f'dbo_{t}' for t in SOURCE}
    if set(ckpt) != exp:
        raise RuntimeError(f'CDC checkpoints missing or unexpected: {set(ckpt) ^ exp}')
    if ch.query('SELECT count() FROM Chinook.DimDate').result_rows[0][0] != 33238:
        raise RuntimeError('DimDate is incomplete; aborting')
    return ckpt


def ingest_changes(ms, pg, ckpt):
    cur = ms.cursor()
    cur.execute('SELECT sys.fn_cdc_get_max_lsn()')
    top = lsn_bytes(cur.fetchone()[0])
    bytable = {t: n for t,n in SOURCE.items()}
    count = 0
    for table, dest in bytable.items():
        inst = f'dbo_{table}'
        if ckpt[inst] >= top:
            continue
        cur.execute('SELECT sys.fn_cdc_increment_lsn(%s)', (ckpt[inst],))
        first = lsn_bytes(cur.fetchone()[0])
        cur.execute('SELECT sys.fn_cdc_get_min_lsn(%s)', (inst,))
        minimum = lsn_bytes(cur.fetchone()[0])
        if first < minimum:
            raise RuntimeError(f'CDC retention gap for {inst}; cannot skip lost events. Full resynchronization needed')
        if first > top:
            continue
        # Function identifier comes only from the hardcoded source table allowlist.
        cur.execute(f"SELECT * FROM cdc.fn_cdc_get_all_changes_{inst}(%s,%s,'all') "
                    'ORDER BY __$start_lsn, __$seqval', (first, top))
        col = [d[0] for d in cur.description]
        changes = cur.fetchall()
        with pg.cursor() as pc:
            for offset, line in enumerate(changes):
                data = dict(zip(col, line))
                operation = int(data['__$operation'])
                if operation not in (1, 2, 4):
                    raise RuntimeError(f'Unexpected CDC operation {operation} for {inst}')
                start = lsn_bytes(data['__$start_lsn'])
                seq = lsn_bytes(data['__$seqval'])
                row = {k.lower(): serializable(v) for k,v in data.items()
                       if not k.startswith('__$')}
                key = {x: row[x] for x in PK[dest]}
                # offset disambiguates identical row images within same CDC window
                # (order is stable for normal CDC seqval results).
                raw = json.dumps([inst, start.hex(), seq.hex(), operation,
                                  key, row, offset], sort_keys=True, ensure_ascii=False)
                h = hashlib.sha256(raw.encode('utf8')).hexdigest()
                cur.execute('SELECT sys.fn_cdc_map_lsn_to_time(%s)', (start,))
                commit_time = cur.fetchone()[0]
                pc.execute('''INSERT INTO etl.cdc_events
                    (event_hash,capture_instance,start_lsn,seqval,operation,source_key,row_data,commit_time)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                    ON CONFLICT (event_hash) DO NOTHING''',
                    (h, inst, psycopg2.Binary(start), psycopg2.Binary(seq),
                     operation, Json(key), Json(row), commit_time))
                count += 1
        log.info('CDC %-19s %d captured changes', inst, len(changes))
    pg.commit()  # Durable inbox before any DW writes
    return top, count


def ensure_revisions(pg):
    """Stable ordered ClickHouse revisions per LSN, including across retries."""
    with pg.cursor() as cur:
        cur.execute('''CREATE TABLE IF NOT EXISTS etl.cdc_revision (
            start_lsn bytea PRIMARY KEY,
            revision bigint GENERATED ALWAYS AS IDENTITY UNIQUE
        )''')
        cur.execute('SELECT DISTINCT start_lsn FROM etl.cdc_events WHERE applied_at IS NULL ORDER BY start_lsn')
        lsns = [lsn_bytes(row[0]) for row in cur.fetchall()]
        for lsn in lsns:
            cur.execute('INSERT INTO etl.cdc_revision(start_lsn) VALUES (%s) ON CONFLICT DO NOTHING',
                        (psycopg2.Binary(lsn),))
    pg.commit()


def query_rows(ch, name):
    result = ch.query(f'SELECT * FROM Chinook.{name} FINAL')
    return [dict(zip(result.column_names, vals)) for vals in result.result_rows]


def equal_data(a, b):
    """Compare ClickHouse data independent of Revision and datetime tz representation."""
    keys = set(b) - {'Revision'}
    def norm(v):
        if isinstance(v, datetime):
            return v.replace(tzinfo=None) if v.tzinfo is not None else v
        if isinstance(v, Decimal):
            return v.normalize()
        return v
    return all(norm(a.get(k)) == norm(b[k]) for k in keys)


def as_utc_aware(v):
    """Normalize ClickHouse DateTime64 values to timezone-aware UTC.

    clickhouse-connect interprets naive datetime.timestamp() in the host local
    timezone; without this, rewriting an SCD2 row shifts its ValidFrom.
    Chinook DimTrack/DimCustomer DateTime64 columns explicitly use UTC.
    """
    if isinstance(v, datetime):
        return v.replace(tzinfo=timezone.utc) if v.tzinfo is None else v.astimezone(timezone.utc)
    return v


def write_rows(ch, table, rows):
    if not rows:
        return
    cols = list(rows[0])
    for idx in range(0, len(rows), 1000):
        chunk = rows[idx:idx+1000]
        ch.insert('Chinook.' + table,
                  [[as_utc_aware(row[c]) for c in cols] for row in chunk],
                  column_names=cols)
    log.info('DW %-18s %d changed row versions', table, len(rows))


def item_key(row, name):
    return int(row[name])


def stage_group(pg, events):
    with pg.cursor() as cur:
        # Never accept arbitrary table/column identifiers from JSON CDC events.
        columns = {}
        for name in SOURCE.values():
            cur.execute('''SELECT column_name FROM information_schema.columns
                           WHERE table_schema='stg' AND table_name=%s''', (name,))
            columns[name] = {r[0] for r in cur.fetchall()} - {'linetotal','_extracted_at'}
        for event in events:
            inst, op, key, row = event['capture_instance'], event['operation'], event['source_key'], event['row_data']
            table = SOURCE[inst.removeprefix('dbo_')]
            allowed = columns[table]
            if op == 1:
                stmt = sql.SQL('DELETE FROM stg.{} WHERE ').format(sql.Identifier(table))
                stmt += sql.SQL(' AND ').join(sql.SQL('{}=%s').format(sql.Identifier(k)) for k in PK[table])
                cur.execute(stmt, [key[k] for k in PK[table]])
            else:
                source_cols = [c for c in row if c in allowed]
                if set(source_cols) != allowed:
                    raise RuntimeError(f'CDC schema drift: {table} expected {allowed}, got {set(source_cols)}')
                stmt = sql.SQL('INSERT INTO stg.{} ({}) VALUES ({}) ON CONFLICT ({}) DO UPDATE SET {}').format(
                    sql.Identifier(table),
                    sql.SQL(', ').join(map(sql.Identifier, source_cols)),
                    sql.SQL(', ').join(sql.Placeholder() for _ in source_cols),
                    sql.SQL(', ').join(map(sql.Identifier, PK[table])),
                    sql.SQL(', ').join(
                        [sql.SQL('{}=EXCLUDED.{}').format(sql.Identifier(c),sql.Identifier(c))
                         for c in source_cols if c not in PK[table]] +
                        [sql.SQL('_extracted_at=now()')]))
                cur.execute(stmt, [row[c] for c in source_cols])


def as_timestamp(dt):
    if dt is None:
        raise RuntimeError('SQL Server CDC commit timestamp unavailable')
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def reconcile(pg, ch, rev, lsn, when):
    """Reconcile the staging snapshot as of one committed CDC transaction.
    Type2 customer/track versions use commit time; type1 and fact use versioned upserts.
    Historical FactInvoice keys are preserved when source FK IDs are unchanged.
    """
    data = stage_frames(pg)
    items = {k:list(records(v)) for k,v in data.items()}
    existing = {dim:query_rows(ch, dim) for dim in DIM_TABLES}
    pending = defaultdict(list)

    with pg.cursor() as cur:
        # Geography: UNION ALL of source location sets then DISTINCT.
        geo_records = set()
        for t in ('customer','employee'):
            geo_records.update(geo_key(r) for r in items[t])
        geo_records.update(geo_key(r, True) for r in items['invoice'])
        geokeys = {tuple(row[a] for a in ('Address','City','State','Country','PostalCode')):row['GeographyKey']
                   for row in existing['DimGeography']}
        for location in sorted(geo_records, key=str):
            if all(part is None for part in location):
                continue
            if location not in geokeys:
                digest = hashlib.sha256(json.dumps(location, ensure_ascii=False).encode()).hexdigest()
                k = surrogate(cur,'DimGeography',digest)
                geokeys[location] = k
                pending['DimGeography'].append(dict(zip(
                    ['GeographyKey','Address','City','State','Country','PostalCode','Revision'],
                    [k,*location,rev])))
        getgeo = lambda r, billing=False: geokeys.get(geo_key(r,billing))

        emp_key = {r['employeeid']:surrogate(cur,'DimEmployee',r['employeeid']) for r in items['employee']}
        album_key = {r['albumid']:surrogate(cur,'DimAlbum',r['albumid']) for r in items['album']}
        playlist_key = {r['playlistid']:surrogate(cur,'DimPlaylist',r['playlistid']) for r in items['playlist']}
        artist = {r['artistid']:r['name'] for r in items['artist']}
        genres = {r['genreid']:r['name'] for r in items['genre']}
        media = {r['mediatypeid']:r['name'] for r in items['mediatype']}

        def type1(table, rows, alt):
            old = {r[alt]:r for r in existing[table]}
            for fresh in rows:
                prior = old.get(fresh[alt])
                if prior is None or not equal_data(prior,fresh):
                    pending[table].append(fresh)
            deleted = set(old) - {r[alt] for r in rows}
            if deleted:
                # Current schema has no IsDeleted on these dimensions.
                # Refuse unsafe silent loss or destructive CH mutations.
                raise RuntimeError(f'{table}: source deleted IDs {sorted(deleted)}. '
                                   'Needs a reviewed Type1 deletion policy before advancing LSN')

        type1('DimEmployee', [dict(zip(
            ['EmployeeKey','EmployeeAlternateKey','LastName','FirstName','Title','ReportsToKey',
             'BirthDateKey','HireDateKey','GeographyKey','Phone','Fax','Email','Department',
             'Salary','Revision'],
            [emp_key[r['employeeid']],r['employeeid'],r['lastname'],r['firstname'],r['title'],
             emp_key.get(r['reportsto']),date_key(r['birthdate']),date_key(r['hiredate']),
             getgeo(r),r['phone'],r['fax'],r['email'],r['department'],r['salary'],rev]))
             for r in items['employee']], 'EmployeeAlternateKey')
        type1('DimAlbum', [dict(zip(
            ['AlbumKey','AlbumAlternateKey','Title','ArtistName','Revision'],
            [album_key[r['albumid']],r['albumid'],r['title'],artist.get(r['artistid']),rev]))
            for r in items['album']], 'AlbumAlternateKey')
        type1('DimPlaylist', [dict(zip(
            ['PlaylistKey','PlaylistAlternateKey','Name','Revision'],
            [playlist_key[r['playlistid']],r['playlistid'],r['name'],rev]))
            for r in items['playlist']], 'PlaylistAlternateKey')

        def type2(table, alternate, keyname, desired):
            current = {r[alternate]:r for r in existing[table] if r['IsCurrent'] == 1}
            # For retry after close succeeds but new version fails: there may
            # be no current version. The stable LSN version token recovers it.
            sk_map = {}
            for alt, values in desired.items():
                before = current.get(alt)
                if before is not None and all(before.get(k)==v for k,v in values.items()):
                    sk_map[alt] = int(before[keyname])
                    continue
                if before is not None:
                    closed = {**before,'ValidTo':when,'IsCurrent':0,'Revision':rev}
                    pending[table].append(closed)
                token = lsn.hex()
                newsk = surrogate(cur,table,alt,token)
                item = {keyname:newsk,alternate:alt,**values,
                        'ValidFrom':when,'ValidTo':None,'IsCurrent':1,'Revision':rev}
                pending[table].append(item)
                sk_map[alt] = newsk
            for alt, old in current.items():
                if alt not in desired:
                    pending[table].append({**old,'ValidTo':when,'IsCurrent':0,'Revision':rev})
            return sk_map

        cust_values = {r['customerid']:dict(
            FirstName=r['firstname'],LastName=r['lastname'],Company=r['company'],
            Phone=r['phone'],Fax=r['fax'],Email=r['email'],
            GeographyKey=getgeo(r),SupportRepKey=emp_key.get(r['supportrepid']))
            for r in items['customer']}
        customer_keys = type2('DimCustomer','CustomerAlternateKey','CustomerKey',cust_values)

        track_values = {r['trackid']:dict(
            Name=r['name'],AlbumKey=album_key.get(r['albumid']),
            GenreName=genres.get(r['genreid']),MediaTypeName=media.get(r['mediatypeid']),
            Composer=r['composer'],Milliseconds=r['milliseconds'],Bytes=r['bytes'],
            UnitPrice=r['unitprice']) for r in items['track']}
        track_keys = type2('DimTrack','TrackAlternateKey','TrackKey',track_values)

        # Preserve historical fact surrogate references unless the actual
        # source invoice CustomerId or line TrackId changes.
        old_customer_alt = {r['CustomerKey']:r['CustomerAlternateKey'] for r in existing['DimCustomer']}
        old_track_alt = {r['TrackKey']:r['TrackAlternateKey'] for r in existing['DimTrack']}
        active_pairs = {(r['PlaylistKey'],r['TrackKey']):r for r in existing['DimPlaylistTrack']
                        if r['IsActive'] == 1}
        want_pairs = {(playlist_key[r['playlistid']],track_keys[r['trackid']])
                      for r in items['playlisttrack']}
        for key in want_pairs - set(active_pairs):
            pending['DimPlaylistTrack'].append(dict(PlaylistKey=key[0],TrackKey=key[1],
                                                    IsActive=1,Revision=rev))
        for key in set(active_pairs) - want_pairs:
            pending['DimPlaylistTrack'].append({**active_pairs[key], 'IsActive':0,'Revision':rev})

        invoices = {r['invoiceid']:r for r in items['invoice']}
        old_facts = {r['InvoiceLineId']:r for r in existing['FactInvoice']}
        active_line_ids = set()
        for line in items['invoiceline']:
            iv = invoices.get(line['invoiceid'])
            if iv is None:
                raise RuntimeError('InvoiceLine references a missing Invoice')
            id_ = line['invoicelineid']
            active_line_ids.add(id_)
            old = old_facts.get(id_)
            customer_key = customer_keys[iv['customerid']]
            track_key = track_keys[line['trackid']]
            if old and not old['IsDeleted']:
                if old_customer_alt.get(old['CustomerKey']) == iv['customerid']:
                    customer_key = old['CustomerKey']
                if old_track_alt.get(old['TrackKey']) == line['trackid']:
                    track_key = old['TrackKey']
            fresh = dict(InvoiceLineId=id_,InvoiceId=line['invoiceid'],CustomerKey=customer_key,
                         TrackKey=track_key,GeographyKey=getgeo(iv, True),
                         InvoiceDateKey=date_key(iv['invoicedate']),UnitPrice=line['unitprice'],
                         Quantity=line['quantity'],Discount=line['discount'],
                         LineTotal=line['linetotal'],IsDeleted=0,Revision=rev)
            if old is None or not equal_data(old,fresh):
                pending['FactInvoice'].append(fresh)
        for id_,old in old_facts.items():
            if id_ not in active_line_ids and not old['IsDeleted']:
                pending['FactInvoice'].append({**old,'IsDeleted':1,'Revision':rev})

    # CH writes ordered: geography/Type1 dims, historical SCD closure before
    # new version, bridge, facts. Retries compare FINAL and insert missing rows.
    for table in DIM_TABLES:
        write_rows(ch, table, pending[table])


def validate(pg, ch):
    """Only advance checkpoints when post-apply invariants hold."""
    with pg.cursor() as cur:
        cur.execute('SELECT count(*), coalesce(sum(linetotal),0) FROM stg.invoiceline')
        expected, total = cur.fetchone()
        cur.execute('SELECT count(*) FROM stg.customer')
        cust_count = cur.fetchone()[0]
        cur.execute('SELECT count(*) FROM stg.track')
        track_count = cur.fetchone()[0]
        cur.execute('SELECT count(*) FROM stg.playlisttrack')
        membership_count = cur.fetchone()[0]
    queries = {
        'facts': 'SELECT count(),coalesce(sum(LineTotal),0) FROM Chinook.FactInvoice FINAL WHERE IsDeleted=0',
        'cust': 'SELECT count() FROM Chinook.DimCustomer FINAL WHERE IsCurrent=1',
        'track': 'SELECT count() FROM Chinook.DimTrack FINAL WHERE IsCurrent=1',
        'member': 'SELECT count() FROM Chinook.DimPlaylistTrack FINAL WHERE IsActive=1',
    }
    cnt, amount = ch.query(queries['facts']).result_rows[0]
    if cnt != expected or abs(Decimal(str(amount)) - total) > Decimal('0.01'):
        raise RuntimeError(f'Fact validation failed: rows {cnt}/{expected}, sums {amount}/{total}')
    for label,exp in [('cust',cust_count),('track',track_count),('member',membership_count)]:
        found = ch.query(queries[label]).result_rows[0][0]
        if found != exp:
            raise RuntimeError(f'{label} current rows {found} != staging {exp}')


def main():
    if not (ROOT / '.env').is_file():
        raise RuntimeError('Place the cdc folder directly inside the project root')
    env = read_env(ROOT / '.env')
    ms = pymssql.connect(server=cfg(env,'SQLSERVER_HOST','127.0.0.1'),port=int(cfg(env,'SQLSERVER_PORT','1433')),
                         user='sa',password=cfg(env,'MSSQL_SA_PASSWORD'),database='Chinook',
                         charset='UTF-8',login_timeout=20,timeout=120)
    ms.autocommit(True)
    pg = psycopg2.connect(host=cfg(env,'STAGING_HOST','127.0.0.1'),port=int(cfg(env,'STAGING_PORT','5432')),
                         user='etl_user',password=cfg(env,'POSTGRES_PASSWORD'),dbname='chinook_staging',
                         connect_timeout=20)
    ch = clickhouse_connect.get_client(host=cfg(env,'DW_HOST','127.0.0.1'),
            port=int(cfg(env,'DW_PORT','8123')),username='etl_user',
            password=cfg(env,'CLICKHOUSE_PASSWORD'),database='Chinook',
            connect_timeout=15,send_receive_timeout=120)
    rid = None
    try:
        with pg.cursor() as cur:
            cur.execute('SELECT pg_try_advisory_lock(98261120)')
            if not cur.fetchone()[0]:
                raise RuntimeError('Another incremental loader is already running')
        checkpoint = ensure_completed_full_load(pg,ch)
        with pg.cursor() as cur:
            cur.execute("INSERT INTO etl.pipeline_run(load_kind,state,notes) VALUES ('incremental','running','CDC incremental') RETURNING run_id")
            rid = cur.fetchone()[0]
        pg.commit()
        upper, captured = ingest_changes(ms,pg,checkpoint)
        ensure_revisions(pg)
        with pg.cursor() as cur:
            cur.execute('''SELECT event_id,capture_instance,start_lsn,seqval,operation,
                                  source_key,row_data,commit_time
                           FROM etl.cdc_events WHERE applied_at IS NULL
                           ORDER BY start_lsn,seqval,event_id''')
            pending = [dict(zip(['event_id','capture_instance','start_lsn','seqval','operation',
                                 'source_key','row_data','commit_time'],r)) for r in cur.fetchall()]
        groups = defaultdict(list)
        for event in pending:
            groups[lsn_bytes(event['start_lsn'])].append(event)
        for idx,(lsn, events) in enumerate(groups.items(), 1):
            with pg.cursor() as cur:
                cur.execute('SELECT revision FROM etl.cdc_revision WHERE start_lsn=%s',
                            (psycopg2.Binary(lsn),))
                rev = int(cur.fetchone()[0]) + 1
            commit_times = {e['commit_time'] for e in events if e['commit_time'] is not None}
            if len(commit_times) != 1:
                raise RuntimeError(f'Inconsistent CDC commit timestamps for LSN {lsn.hex()}')
            at = as_timestamp(next(iter(commit_times)))
            try:
                stage_group(pg,events)
                reconcile(pg,ch,rev,lsn,at)
                validate(pg,ch)
                with pg.cursor() as cur:
                    cur.execute('UPDATE etl.cdc_events SET applied_at=now() WHERE event_id=ANY(%s)',
                                ([e['event_id'] for e in events],))
                pg.commit()
                log.info('Applied CDC transaction %d/%d LSN=%s events=%d',
                         idx,len(groups),lsn.hex(),len(events))
            except Exception:
                pg.rollback()
                raise
        # A checkpoint at captured maximum LSN is safe only after ALL pending
        # events are committed, with or without business changes this run.
        with pg.cursor() as cur:
            cur.execute('SELECT count(*) FROM etl.cdc_events WHERE applied_at IS NULL')
            if cur.fetchone()[0]:
                raise RuntimeError('Pending CDC events remain; refusing to advance checkpoints')
            for inst in checkpoint:
                cur.execute('''UPDATE etl.cdc_checkpoint SET last_lsn=%s, updated_at=now()
                               WHERE capture_instance=%s AND last_lsn<=%s''',
                            (psycopg2.Binary(upper),inst,psycopg2.Binary(upper)))
            cur.execute('''UPDATE etl.pipeline_run SET state='completed',finished_at=now(),
                           notes=%s WHERE run_id=%s''',
                        (f'Captured {captured} changes, applied {len(pending)} events in {len(groups)} transactions',rid))
        pg.commit()
        log.info('SUCCESS: incremental CDC complete; captured=%d applied=%d transactions=%d',
                 captured,len(pending),len(groups))
    except Exception:
        pg.rollback()
        if rid:
            try:
                with pg.cursor() as cur:
                    cur.execute("UPDATE etl.pipeline_run SET state='failed',finished_at=now(),notes='See terminal error' WHERE run_id=%s", (rid,))
                pg.commit()
            except Exception:
                pg.rollback()
        log.exception('FAILED: CDC checkpoint did not advance beyond successfully committed groups')
        sys.exit(1)
    finally:
        ch.close()
        pg.close()
        ms.close()


if __name__ == '__main__':
    main()
