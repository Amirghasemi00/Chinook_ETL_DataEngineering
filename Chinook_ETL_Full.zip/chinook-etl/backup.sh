#!/usr/bin/env bash
# Consistent COLD backup of volumes. Stops running project containers, restores them on exit.
set -Eeuo pipefail
umask 077
cd "$(dirname "$0")"
[[ $# == 1 && "$1" == /* ]] || { echo 'Usage: bash backup.sh /absolute/private/backup/folder' >&2; exit 2; }
[[ -f .env ]] || { echo '.env missing' >&2; exit 1; }
DC=(docker compose -f compose.yaml)
out="${1%/}/chinook-backup-$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$out"
chmod 700 "$out"
# Ensure tar-capable base image already present; avoid Docker Hub.
image='public.ecr.aws/docker/library/postgres:16'
docker image inspect "$image" >/dev/null 2>&1 || { echo "Required local image $image absent" >&2; exit 1; }
mapfile -t running < <("${DC[@]}" ps --services --status running)
resume() {
  if ((${#running[@]})); then
    printf '\n==> Resuming previously running project services\n'
    "${DC[@]}" start "${running[@]}" || echo 'WARNING: one or more services did not restart. Inspect docker compose ps.' >&2
  fi
}
trap resume EXIT
printf '==> Stopping %d project services to obtain a consistent cold backup\n' "${#running[@]}"
if ((${#running[@]})); then "${DC[@]}" stop --timeout 90 "${running[@]}"; fi
printf '==> Copying five Docker named volumes. Do not restart this stack until backup completes.\n'
for part in sqlserver_data postgres_data clickhouse_data chinook_airflow_home chinook_grafana_data; do
  volume="chinook-etl-portable_${part}"
  docker volume inspect "$volume" >/dev/null || { echo "Missing volume: $volume" >&2; exit 1; }
  docker run --rm --pull never \
    --entrypoint tar \
    -v "$volume:/source:ro" -v "$out:/out" \
    "$image" -C /source -czf "/out/${part}.tar.gz" .
  echo "Saved: ${part}.tar.gz"
done
cp .env "$out/.env"
chmod 600 "$out/.env"
(
  cd "$out"
  sha256sum ./*.tar.gz .env > SHA256SUMS
)
cat > "$out/README.txt" <<'TXT'
Offline cold backup of the chinook-etl-portable stack.
Preserve ALL five tar.gz archives, the exact .env credentials, and the original project source release.
Restore only to an isolated, stopped stack. Never overwrite a running installation.
This backup contains credentials and potentially confidential data; store securely.
TXT
printf '\nBackup complete: %s\n' "$out"
