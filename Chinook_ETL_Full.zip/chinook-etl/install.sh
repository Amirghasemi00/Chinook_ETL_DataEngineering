#!/usr/bin/env bash
# Installs the local Chinook pipeline without replacing existing database volumes.
set -Eeuo pipefail
umask 077
cd "$(dirname "${BASH_SOURCE[0]}")"
ROOT="$PWD"
DC=(docker compose -f "$ROOT/compose.yaml")

log() { printf '\n==> %s\n' "$*"; }
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
trap 'echo "INSTALL STOPPED at line $LINENO. No Docker volumes were deleted. Inspect the error, then rerun bash install.sh." >&2' ERR

[[ ${1:-} == '' || ${1:-} == '--rebuild' ]] || die 'Usage: bash install.sh [--rebuild]'
REBUILD=false
[[ ${1:-} == '--rebuild' ]] && REBUILD=true
[[ -f compose.yaml && -f sqlserver/setup/seed_data.sql ]] || die 'This does not look like the complete portable project.'
[[ -r /proc/version ]] || die 'Linux /proc/version is unavailable.'
if ! grep -qiE '(microsoft|wsl)' /proc/version; then
  echo 'WARNING: This stack was designed for WSL2 Ubuntu. Proceeding on Linux without WSL-specific checks.'
fi
command -v python3 >/dev/null || die 'Python 3 is required. Install: sudo apt update && sudo apt install -y python3'
command -v curl >/dev/null || die 'curl is required. Install: sudo apt update && sudo apt install -y curl'
command -v docker >/dev/null || die 'Docker Engine missing. See README.md.'
docker compose version >/dev/null 2>&1 || die 'Docker Compose v2 missing. See README.md.'
docker info >/dev/null 2>&1 || die 'Docker daemon unavailable or user lacks Docker permissions. See README.md.'
if [[ ! -f .env ]]; then
  if docker volume ls --format '{{.Name}}' | grep -Eq '^chinook-etl-portable_(sqlserver_data|postgres_data|clickhouse_data|chinook_airflow_home|chinook_grafana_data)$'; then
    die 'Project Docker volumes exist but .env is absent. Restore original .env from your private backup; never generate new passwords for old volumes.'
  fi
fi
python3 scripts/create_env.py
"${DC[@]}" config --quiet

# Prevent a second stack from colliding with this one on first startup.
if [[ -z "$("${DC[@]}" ps -aq 2>/dev/null)" ]]; then
  python3 - <<'PY'
import socket
busy=[]
for port in (1433,5432,8123,9000,8080,3000):
    s=socket.socket()
    try: s.bind(('127.0.0.1',port))
    except OSError: busy.append(port)
    finally: s.close()
if busy:
    raise SystemExit(f'Host ports {busy} are occupied by another application. Stop that application or use a different host before installation.')
PY
fi

image_ensure() {
  local service="$1" image="$2"
  if $REBUILD || ! docker image inspect "$image" >/dev/null 2>&1; then
    log "Building $service image (this may require a substantial download)"
    "${DC[@]}" build "$service"
  else
    echo "Reusing cached image: $image"
  fi
}

log 'Obtain SQL Server and PostgreSQL from accessible registries'
if ! docker image inspect 'mcr.microsoft.com/mssql/server:2022-latest' >/dev/null 2>&1; then
  docker pull 'mcr.microsoft.com/mssql/server:2022-latest'
fi
if ! docker image inspect 'public.ecr.aws/docker/library/postgres:16' >/dev/null 2>&1; then
  docker pull 'public.ecr.aws/docker/library/postgres:16'
fi
image_ensure clickhouse 'chinook-clickhouse:portable-local'

log 'Start only source and database services (persistent volumes)'
"${DC[@]}" up -d --no-deps --pull never sqlserver
"${DC[@]}" up -d --wait --no-deps --pull never postgres clickhouse

sql_chinook_exists() {
  "${DC[@]}" exec -T sqlserver /bin/bash -lc '
    set -euo pipefail
    if [[ -x /opt/mssql-tools18/bin/sqlcmd ]]; then sqlcmd=/opt/mssql-tools18/bin/sqlcmd
    elif [[ -x /opt/mssql-tools/bin/sqlcmd ]]; then sqlcmd=/opt/mssql-tools/bin/sqlcmd
    else exit 127; fi
    export SQLCMDPASSWORD="${MSSQL_SA_PASSWORD:?}"
    exec "$sqlcmd" -S localhost -U sa -C -b -h -1 -W -l 5 \
      -Q "SET NOCOUNT ON; SELECT CASE WHEN DB_ID(N'\''Chinook'\'') IS NULL THEN 0 ELSE 1 END;"
  ' | tr -d '\r[:space:]'
}
sql_source_valid() {
  "${DC[@]}" exec -T sqlserver /bin/bash -lc '
    set -euo pipefail
    if [[ -x /opt/mssql-tools18/bin/sqlcmd ]]; then sqlcmd=/opt/mssql-tools18/bin/sqlcmd
    elif [[ -x /opt/mssql-tools/bin/sqlcmd ]]; then sqlcmd=/opt/mssql-tools/bin/sqlcmd
    else exit 127; fi
    export SQLCMDPASSWORD="${MSSQL_SA_PASSWORD:?}"
    exec "$sqlcmd" -S localhost -U sa -C -b -h -1 -W -l 5 \
      -d Chinook -Q "SET NOCOUNT ON; SELECT CASE WHEN (SELECT COUNT(*) FROM cdc.change_tables) = 11 AND (SELECT COUNT(*) FROM dbo.InvoiceLine) > 0 THEN 1 ELSE 0 END;"
  ' | tr -d '\r[:space:]'
}

log 'Check SQL Server Chinook source without overwriting existing data'
ready=''
for _ in {1..60}; do
  if ready="$(sql_chinook_exists 2>/dev/null)" && [[ "$ready" == '0' || "$ready" == '1' ]]; then
    break
  fi
  sleep 3
done
[[ "$ready" == '0' || "$ready" == '1' ]] || die 'SQL Server did not become ready or sqlcmd missing. Check docker compose logs sqlserver.'
if [[ "$ready" == '0' ]]; then
  log 'First installation: seed Chinook and enable 11 CDC capture tables'
  bash sqlserver/setup/run_install.sh
else
  echo 'Existing Chinook database found; skipping all source inserts.'
fi
[[ "$(sql_source_valid)" == '1' ]] || die 'Chinook exists but its source/CDC validation failed. Manual repair required; installer will not replace it.'

log 'Prepare PostgreSQL staging and ClickHouse DW schemas (safe if already present)'
bash database_setup/run_setup.sh
log 'Ensure the separate Airflow metadata database exists'
"${DC[@]}" exec -T postgres sh -lc 'psql -X -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"' <<'SQL'
SELECT format('CREATE DATABASE %I OWNER %I', 'airflow', current_user)
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname='airflow')
\gexec
SQL

image_ensure chinook-airflow 'chinook-airflow:2.10.5-portable-local'

completed="$("${DC[@]}" exec -T postgres sh -lc \
 'psql -X -v ON_ERROR_STOP=1 -At -U "$POSTGRES_USER" -d chinook_staging -c "SELECT count(*) FROM etl.pipeline_run WHERE load_kind='\''full'\'' AND state='\''completed'\''"' | tr -d '\r[:space:]')"
[[ "$completed" =~ ^[0-9]+$ && "$completed" -le 1 ]] || die "Unsafe full-load state: completed run count='$completed'"
if [[ "$completed" == '0' ]]; then
  log 'ONE-TIME FULL LOAD: SQL Server -> PostgreSQL -> ClickHouse (never rerun after completed)'
  echo 'Do not modify the source database while initial loading runs.'
  "${DC[@]}" run --rm --no-deps --entrypoint python chinook-airflow \
    -u /opt/etl/full_load/full_load.py
else
  echo 'Completed Full Load already present. Skipping it and preserving CDC checkpoints.'
fi

log 'Provision dedicated read-only Grafana reporting login'
"${DC[@]}" run --rm --no-deps --entrypoint python chinook-airflow \
  -u /opt/etl/reporting/create_role.py
log 'Mirror the warehouse to rpt schema transactionally'
"${DC[@]}" run --rm --no-deps --entrypoint python chinook-airflow \
  -u /opt/etl/reporting/sync_dw.py

image_ensure chinook-grafana 'chinook-grafana:13.3.1-portable-local'
log 'Start Airflow and Grafana (no other services recreated)'
"${DC[@]}" up -d --no-deps --pull never chinook-airflow chinook-grafana

log 'Check Airflow metadata and Grafana HTTP availability'
airflow_ready=false
grafana_ready=false
for _ in {1..90}; do
  if "${DC[@]}" exec -T chinook-airflow airflow db check >/dev/null 2>&1 && \
     curl -fsS --max-time 4 http://127.0.0.1:8080/health >/dev/null 2>&1; then
    airflow_ready=true
  fi
  if curl -fsS --max-time 4 http://127.0.0.1:3000/api/health >/dev/null 2>&1; then
    grafana_ready=true
  fi
  if $airflow_ready && $grafana_ready; then break; fi
  sleep 4
done
$airflow_ready || die 'Airflow not ready. Check docker compose logs chinook-airflow.'
$grafana_ready || die 'Grafana not ready. Check docker compose logs chinook-grafana.'

log 'Verify DW and reporting data before enabling CDC scheduling'
bash verify.sh --data-only
log 'Verify the DAGs import cleanly'
errors="$("${DC[@]}" exec -T chinook-airflow airflow dags list-import-errors 2>/dev/null)"
if [[ "$errors" != *'No data found'* ]]; then
  printf '%s\n' "$errors" >&2
  die 'Airflow reported DAG import errors'
fi

if [[ -f .install_complete ]]; then
  log 'Already-installed instance: preserving operator-selected DAG pause states'
else
  log 'First completed installation: enabling both DAG schedules'
  for dag in chinook_incremental_cdc chinook_dw_reporting_refresh; do
    active=false
    for _ in {1..50}; do
      "${DC[@]}" exec -T chinook-airflow airflow dags unpause "$dag" >/dev/null 2>&1 || true
      row="$("${DC[@]}" exec -T chinook-airflow airflow dags list 2>/dev/null | grep -E "^${dag}[[:space:]]*\\|" || true)"
      if [[ "$row" == *'False'* ]]; then active=true; break; fi
      sleep 3
    done
    $active || die "DAG '$dag' was not registered as active. Review Airflow UI before retrying."
    echo "Enabled: $dag"
  done
  # Marker is written only after data, Grafana, Airflow and both DAGs succeed.
  printf 'Installed on %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > .install_complete
  chmod 600 .install_complete
fi

log 'Installation complete — all data remains in named Docker volumes'
"${DC[@]}" ps
cat <<'TEXT'

Open locally:
  Airflow:  http://localhost:8080  (admin; password in Airflow container file)
  Grafana: http://localhost:3000  (admin; password in private .env)

Useful commands:
  bash verify.sh
  bash status.sh
  bash secrets-help.sh
  bash backup.sh /path/to/private-backup-directory

Never run `docker compose down -v` or `docker volume prune` on this project.
Do not upload .env or backups containing business data/secrets.
TEXT
