#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
DC=(docker compose -f compose.yaml)
[[ -f .env ]] || { echo 'ERROR: .env missing. Run install.sh first.' >&2; exit 1; }
[[ ${1:-} == '' || ${1:-} == '--data-only' ]] || { echo 'Usage: bash verify.sh [--data-only]' >&2; exit 2; }
echo '==> Validate databases, CDC checkpoints and reporting mirror (read-only)'
"${DC[@]}" run --rm --no-deps --entrypoint python chinook-airflow \
 -u /opt/etl/scripts/verify_data.py
if [[ ${1:-} == '--data-only' ]]; then exit 0; fi
printf '\n==> Running services\n'
"${DC[@]}" ps
printf '\n==> Airflow webserver\n'
curl -fsS --max-time 10 http://127.0.0.1:8080/health | python3 -m json.tool | head -35
printf '\n==> Grafana webserver\n'
curl -fsS --max-time 10 http://127.0.0.1:3000/api/health | python3 -m json.tool
printf '\n==> Airflow DAGs\n'
"${DC[@]}" exec -T chinook-airflow airflow dags list 2>/dev/null | grep -E 'dag_id|chinook_incremental_cdc|chinook_dw_reporting_refresh'
printf '\n==> Provisioned Grafana data source and dashboard count\n'
python3 - <<'PY'
from pathlib import Path
import base64,json,urllib.request
v={}
for l in Path('.env').read_text().splitlines():
    if '=' in l and not l.startswith('#'):
        k,a=l.split('=',1);v[k]=a
head={'Authorization':'Basic '+base64.b64encode(('admin:'+v['GRAFANA_ADMIN_PASSWORD']).encode()).decode()}
for u in ('/api/datasources/uid/chinook_clickhouse','/api/search?type=dash-db'):
    with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:3000'+u,headers=head),timeout=15) as resp:
        d=json.load(resp)
    if isinstance(d,list):
        titles=sorted(x.get('title','') for x in d)
        print('Dashboard titles:', ', '.join(titles))
        assert 'Sales Overview' in ' '.join(titles) and 'Music' in ' '.join(titles), 'Expected dashboards not found'
    else:
        assert d.get('uid')=='chinook_clickhouse' and d.get('url')=='postgres:5432'
        assert (d.get('jsonData') or {}).get('database')=='chinook_staging', 'Default PG database missing'
        print('Datasource:',d.get('name'), d.get('type'), d.get('url'))
print('PASS: Grafana provisioned successfully')
PY
printf '\nAll programmatic checks passed. Check chart visuals manually in Grafana.\n'
