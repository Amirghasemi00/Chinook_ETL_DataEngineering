import os
import sys
from urllib.parse import quote

user = quote(os.environ.get("POSTGRES_USER", "etl_user"), safe="")
password = quote(os.environ["POSTGRES_PASSWORD"], safe="")

sys.stdout.write(
    f"postgresql+psycopg2://{user}:{password}"
    "@postgres:5432/airflow"
)
