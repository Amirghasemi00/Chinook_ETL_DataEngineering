"""Schedule only the EXISTING incremental loader; never rerun the Full Load.

Paused on creation until verification. SQL Server CDC LSN checkpointing,
Postgres advisory lock, retries and SCD rules remain owned by the CDC loader.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="chinook_incremental_cdc",
    description="Chinook CDC LSN -> PostgreSQL staging -> ClickHouse DW",
    schedule_interval="*/5 * * * *",
    start_date=datetime(2026, 1, 1, tzinfo=timezone.utc),
    catchup=False,
    max_active_runs=1,
    default_args={
        "owner": "data-engineering",
        "retries": 2,
        "retry_delay": timedelta(minutes=1),
        "execution_timeout": timedelta(minutes=10),
    },
    tags=["chinook", "cdc", "data-engineering"],
    is_paused_upon_creation=True,
) as dag:
    incremental_cdc = BashOperator(
        task_id="incremental_cdc",
        bash_command="python -u /opt/etl/cdc/incremental.py",
        cwd="/opt/etl",
        append_env=True,
    )
