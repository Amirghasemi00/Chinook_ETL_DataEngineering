"""Refresh the PostgreSQL reporting mirror after regular CDC ingestion.

Runs at :02/:07/... (two minutes after the CDC's :00/:05/... schedule).
The read model updates atomically, and this DAG doesn't change CDC checkpoints.
"""
from datetime import datetime, timedelta, timezone
from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id='chinook_dw_reporting_refresh',
    description='Mirror ClickHouse DW snapshots to native PostgreSQL for Grafana',
    schedule_interval='2-59/5 * * * *',
    start_date=datetime(2026, 1, 1, tzinfo=timezone.utc),
    catchup=False,
    max_active_runs=1,
    default_args={
        'owner': 'data-engineering',
        'retries': 2,
        'retry_delay': timedelta(minutes=1),
        'execution_timeout': timedelta(minutes=10),
    },
    tags=['chinook', 'grafana', 'dw-reporting'],
    is_paused_upon_creation=True,
) as dag:
    refresh_dw_reporting = BashOperator(
        task_id='refresh_dw_reporting',
        bash_command='python -u /opt/etl/reporting/sync_dw.py',
        cwd='/opt/etl',
        append_env=True,
    )
