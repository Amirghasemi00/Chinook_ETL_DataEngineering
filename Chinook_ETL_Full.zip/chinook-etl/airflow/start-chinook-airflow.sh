#!/usr/bin/env bash
set -Eeuo pipefail

: "${POSTGRES_PASSWORD:?Missing POSTGRES_PASSWORD}"
: "${MSSQL_SA_PASSWORD:?Missing MSSQL_SA_PASSWORD}"
: "${CLICKHOUSE_PASSWORD:?Missing CLICKHOUSE_PASSWORD}"

# Build URL with correct escaping. Never echo credentials into logs.
export AIRFLOW__DATABASE__SQL_ALCHEMY_CONN="$(python - <<'PY'
import os
from urllib.parse import quote
user = quote(os.environ.get('POSTGRES_USER', 'etl_user'), safe='')
pwd = quote(os.environ['POSTGRES_PASSWORD'], safe='')
print(f'postgresql+psycopg2://{user}:{pwd}@postgres:5432/airflow')
PY
)"

# Airflow 2.x standalone initializes metadata DB, webserver, scheduler and
# creates the admin login on first start. Local-development use only.
# AIRFLOW_HOME is a persistent Docker volume. An older webserver PID file can
# survive a cold backup or container restart, and the stored PID may then be
# reused by another Airflow process (e.g. the triggerer). Clear ONLY the old
# webserver PID before starting the new standalone process tree.
# No Airflow process from this container exists yet at entrypoint execution.
webserver_pid_file="${AIRFLOW_HOME:-/opt/airflow}/airflow-webserver.pid"
if [[ -f "$webserver_pid_file" ]]; then
    rm -f -- "$webserver_pid_file"
    echo 'Cleared stale Airflow webserver PID file before startup'
fi

exec airflow standalone
