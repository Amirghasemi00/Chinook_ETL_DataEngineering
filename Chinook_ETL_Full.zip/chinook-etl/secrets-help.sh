#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
echo 'Sensitive: these values will appear on your terminal. Never paste them in chats or screenshots.'
[[ -f .env ]] || { echo '.env missing'; exit 1; }
python3 - <<'PY'
from pathlib import Path
v=dict(l.split('=',1) for l in Path('.env').read_text().splitlines() if '=' in l and not l.startswith('#'))
print('Grafana username: admin')
print('Grafana password:',v['GRAFANA_ADMIN_PASSWORD'])
PY
echo 'Airflow standalone username: admin'
echo 'Airflow password (if initialized):'
docker compose exec -T chinook-airflow cat /opt/airflow/standalone_admin_password.txt
