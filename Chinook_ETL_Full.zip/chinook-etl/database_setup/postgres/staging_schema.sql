-- Chinook staging schema for PostgreSQL 16.
-- Execute inside database chinook_staging, not the Airflow metadata DB.
-- Source identifiers/values are preserved. Business transformations happen downstream.
BEGIN;
CREATE SCHEMA IF NOT EXISTS stg;
CREATE SCHEMA IF NOT EXISTS etl;

CREATE TABLE IF NOT EXISTS stg.artist (
    artistid integer PRIMARY KEY, name text,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.album (
    albumid integer PRIMARY KEY, title text NOT NULL, artistid integer NOT NULL,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.genre (
    genreid integer PRIMARY KEY, name text,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.mediatype (
    mediatypeid integer PRIMARY KEY, name text,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.track (
    trackid integer PRIMARY KEY, name text NOT NULL,
    albumid integer, mediatypeid integer NOT NULL, genreid integer,
    composer text, milliseconds integer NOT NULL, bytes integer,
    unitprice numeric(10,2) NOT NULL,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.employee (
    employeeid integer PRIMARY KEY, lastname text NOT NULL, firstname text NOT NULL,
    title text, reportsto integer, birthdate timestamp, hiredate timestamp,
    address text, city text, state text, country text, postalcode text,
    phone text, fax text, email text, department text, salary numeric(19,4) NOT NULL,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.customer (
    customerid integer PRIMARY KEY, firstname text NOT NULL, lastname text NOT NULL,
    company text, address text, city text, state text, country text, postalcode text,
    phone text, fax text, email text NOT NULL, supportrepid integer,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.invoice (
    invoiceid integer PRIMARY KEY, customerid integer NOT NULL, invoicedate timestamp NOT NULL,
    billingaddress text, billingcity text, billingstate text,
    billingcountry text, billingpostalcode text,
    invoicetotal numeric(14,2) NOT NULL,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.invoiceline (
    invoicelineid integer PRIMARY KEY, invoiceid integer NOT NULL, trackid integer NOT NULL,
    unitprice numeric(10,2) NOT NULL, quantity integer NOT NULL,
    discount numeric(5,2) NOT NULL,
    linetotal numeric(14,2) GENERATED ALWAYS AS
      (((1 - discount) * (unitprice * quantity))::numeric(14,2)) STORED,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.playlist (
    playlistid integer PRIMARY KEY, name text,
    _extracted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS stg.playlisttrack (
    playlistid integer NOT NULL, trackid integer NOT NULL,
    _extracted_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (playlistid, trackid)
);

-- Raw captured events. Source primary key is JSON because PlaylistTrack has a composite key.
-- event_hash provides idempotence across Airflow retries.
CREATE TABLE IF NOT EXISTS etl.cdc_events (
    event_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    event_hash text UNIQUE NOT NULL,
    capture_instance text NOT NULL,
    start_lsn bytea NOT NULL,
    seqval bytea NOT NULL,
    operation smallint NOT NULL,
    source_key jsonb NOT NULL,
    row_data jsonb NOT NULL,
    commit_time timestamp,
    captured_at timestamptz NOT NULL DEFAULT now(),
    applied_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_cdc_events_pending
 ON etl.cdc_events (applied_at, event_id);
CREATE INDEX IF NOT EXISTS idx_cdc_events_lsn
 ON etl.cdc_events (capture_instance, start_lsn, seqval);

-- Checkpoint is the *last successfully committed* source LSN for each capture instance.
CREATE TABLE IF NOT EXISTS etl.cdc_checkpoint (
    capture_instance text PRIMARY KEY,
    last_lsn bytea NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Stable numeric surrogate keys, including a unique token per SCD2 version.
CREATE TABLE IF NOT EXISTS etl.surrogate_key (
    surrogate_key bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    dimension_name text NOT NULL,
    alternate_key text NOT NULL,
    version_token text NOT NULL DEFAULT 'type1',
    UNIQUE (dimension_name, alternate_key, version_token)
);

-- Track full/incremental run state without touching the Airflow metadata DB.
CREATE TABLE IF NOT EXISTS etl.pipeline_run (
    run_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    load_kind text NOT NULL CHECK (load_kind IN ('full','incremental')),
    state text NOT NULL CHECK (state IN ('running','completed','failed')),
    started_at timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz,
    notes text
);
COMMIT;

SELECT schemaname, tablename
FROM pg_tables
WHERE schemaname IN ('stg','etl')
ORDER BY schemaname, tablename;
