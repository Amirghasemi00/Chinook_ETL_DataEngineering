#!/usr/bin/env bash
set -Eeuo pipefail

# Run from the project root.
if [[ ! -f compose.yaml ]]; then
  echo 'ERROR: Run this script from the directory containing compose.yaml.' >&2
  exit 1
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in \
  "$SCRIPT_DIR/postgres/staging_schema.sql" \
  "$SCRIPT_DIR/clickhouse/warehouse_schema.sql" \
  "$SCRIPT_DIR/clickhouse/dim_date.sql"; do
  [[ -f "$f" ]] || { echo "ERROR: Missing $f" >&2; exit 1; }
done

printf '\n==> Starting only Postgres + ClickHouse (SQL Server volume unchanged)\n'
docker compose up -d --wait postgres clickhouse

printf '\n==> Create chinook_staging if it does not exist (preserving airflow DB)\n'
docker compose exec -T postgres sh -lc \
  'exec psql -X -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"' <<'SQL'
SELECT 'CREATE DATABASE chinook_staging'
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'chinook_staging')\gexec
SQL

printf '\n==> Create PostgreSQL source staging + ETL control tables\n'
docker compose exec -T postgres sh -lc \
  'exec psql -X -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d chinook_staging' \
  < "$SCRIPT_DIR/postgres/staging_schema.sql"

printf '\n==> Create the nine ClickHouse warehouse tables\n'
docker compose exec -T clickhouse sh -lc \
  'exec clickhouse-client --user="$CLICKHOUSE_USER" --password="$CLICKHOUSE_PASSWORD" --multiquery' \
  < "$SCRIPT_DIR/clickhouse/warehouse_schema.sql"

printf '\n==> Check DimDate status\n'
DATE_ROWS="$(docker compose exec -T clickhouse sh -lc \
  'exec clickhouse-client --user="$CLICKHOUSE_USER" --password="$CLICKHOUSE_PASSWORD" --query="SELECT count() FROM Chinook.DimDate"' \
  | tr -d '\r[:space:]')"
EXPECTED_ROWS="$(python3 - <<'PY'
from datetime import date
print((date(2030,12,31) - date(1940,1,1)).days + 1)
PY
)"
if [[ "$DATE_ROWS" == '0' ]]; then
  printf '==> Populating DimDate (1940-01-01 to 2030-12-31)\n'
  docker compose exec -T clickhouse sh -lc \
    'exec clickhouse-client --user="$CLICKHOUSE_USER" --password="$CLICKHOUSE_PASSWORD" --multiquery' \
    < "$SCRIPT_DIR/clickhouse/dim_date.sql"
elif [[ "$DATE_ROWS" == "$EXPECTED_ROWS" ]]; then
  printf '==> DimDate already populated: %s rows. Skipping.\n' "$DATE_ROWS"
else
  printf 'ERROR: DimDate contains %s rows; expected 0 or %s. Aborting without replacing data.\n' \
    "$DATE_ROWS" "$EXPECTED_ROWS" >&2
  exit 1
fi

printf '\n==> Validate PostgreSQL\n'
docker compose exec -T postgres sh -lc \
  'exec psql -X -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d chinook_staging -c "SELECT schemaname, count(*) AS table_count FROM pg_tables WHERE schemaname IN ('\''stg'\'', '\''etl'\'') GROUP BY schemaname ORDER BY schemaname"'

printf '\n==> Validate ClickHouse (9 tables, DimDate populated)\n'
docker compose exec -T clickhouse sh -lc \
  'exec clickhouse-client --user="$CLICKHOUSE_USER" --password="$CLICKHOUSE_PASSWORD" --query="SELECT (SELECT count() FROM system.tables WHERE database = '\''Chinook'\'') AS warehouse_tables, count() AS date_rows, min(FullDate) AS min_date, max(FullDate) AS max_date FROM Chinook.DimDate"'

printf '\nSUCCESS: Staging and warehouse schemas created. No business records loaded yet.\n'
