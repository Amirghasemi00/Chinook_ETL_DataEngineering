#!/usr/bin/env python3
"""One-time creation of .env with strong credentials; never changes an existing file."""
from pathlib import Path
import base64
import os
import secrets

root = Path(__file__).resolve().parent.parent
path = root / '.env'
required = [
    'MSSQL_SA_PASSWORD', 'POSTGRES_PASSWORD', 'CLICKHOUSE_PASSWORD',
    'GRAFANA_REPORT_PASSWORD', 'GRAFANA_ADMIN_PASSWORD',
    'GRAFANA_SECRET_KEY', 'AIRFLOW_FERNET_KEY', 'AIRFLOW_SECRET_KEY',
]
if path.is_symlink():
    raise SystemExit('Refusing to follow .env symlink')
if path.exists():
    values = {}
    for line in path.read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        if '=' not in line:
            raise SystemExit('Malformed .env line; refusing to change existing secrets')
        k, v = line.split('=', 1)
        if k in values:
            raise SystemExit(f'Duplicate variable {k} in .env')
        values[k] = v
    missing = [k for k in required if not values.get(k)]
    if missing:
        raise SystemExit('Existing .env incomplete; no passwords changed. Missing: '+', '.join(missing))
    path.chmod(0o600)
    print('Existing .env retained unchanged (values hidden)')
else:
    # SQL Server requires >=3 character classes; use all four with a long random value.
    values = {
        'MSSQL_SA_PASSWORD': 'A' + secrets.token_hex(24) + '!z9',
        'POSTGRES_PASSWORD': secrets.token_hex(24),
        'CLICKHOUSE_PASSWORD': secrets.token_hex(24),
        'GRAFANA_REPORT_PASSWORD': secrets.token_hex(24),
        'GRAFANA_ADMIN_PASSWORD': secrets.token_hex(24),
        'GRAFANA_SECRET_KEY': secrets.token_hex(32),
        'AIRFLOW_FERNET_KEY': base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('ascii'),
        'AIRFLOW_SECRET_KEY': secrets.token_hex(32),
    }
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write('# Generated once by install.sh. NEVER commit or share this file.\n')
        f.writelines(f'{k}={v}\n' for k, v in values.items())
    print('Created private .env (values hidden)')
