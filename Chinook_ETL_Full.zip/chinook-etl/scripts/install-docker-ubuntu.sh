#!/usr/bin/env bash
# Optional: privileged host preparation for Ubuntu 24.04 WSL2, following official Docker apt instructions.
set -Eeuo pipefail
. /etc/os-release
[[ "$ID" == 'ubuntu' ]] || { echo 'Supported only on Ubuntu. See https://docs.docker.com/engine/install/ubuntu/' >&2; exit 1; }
if command -v docker >/dev/null && docker compose version >/dev/null 2>&1; then
  echo 'Docker CLI and Compose already installed. No changes made.'
  exit 0
fi
[[ "$(id -u)" -ne 0 ]] || { echo 'Run as your normal WSL user; this script invokes sudo.' >&2; exit 1; }
if ! command -v sudo >/dev/null; then echo 'sudo required' >&2; exit 1; fi
sudo apt-get update
sudo apt-get install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
arch="$(dpkg --print-architecture)"
release="${UBUNTU_CODENAME:-$VERSION_CODENAME}"
printf 'Types: deb\nURIs: https://download.docker.com/linux/ubuntu\nSuites: %s\nComponents: stable\nArchitectures: %s\nSigned-By: /etc/apt/keyrings/docker.asc\n' "$release" "$arch" | sudo tee /etc/apt/sources.list.d/docker.sources >/dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker "$USER"
echo 'Docker installed. Start a NEW WSL terminal to activate your Docker group membership; then run bash install.sh.'
echo 'Membership in the docker group grants root-equivalent access. Use a trusted local development machine.'
