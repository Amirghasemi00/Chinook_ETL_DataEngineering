#!/usr/bin/env python3
"""Read-only ClickHouse DW -> transactional PostgreSQL reporting snapshot.

Run from the EXISTING Airflow container: all drivers and credentials are present.
Never writes to ClickHouse, SQL Server, stg, etl, or Airflow metadata.
All reporting-table replacements share one PostgreSQL transaction.
"""
import os
import logging
import hashlib
import json
import psycopg2
import clickhouse_connect
from psycopg2 import sql
from psycopg2.extras import execute_values

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger('chinook.reporting')

# SQL names below intentionally preserve ClickHouse DW column capitalization.
SCHEMA = {
    'DimDate': '''
        "DateKey" bigint PRIMARY KEY, "FullDate" date,
        "Year" integer, "Quarter" integer, "Month" integer,
        "MonthName" text, "DayOfMonth" integer, "DayOfWeek" integer,
        "DayName" text, "IsWeekend" integer''',
    'DimGeography': '''
        "GeographyKey" bigint PRIMARY KEY, "Address" text,
        "City" text, "State" text, "Country" text,
        "PostalCode" text, "Revision" bigint''',
    'DimEmployee': '''
        "EmployeeKey" bigint PRIMARY KEY, "EmployeeAlternateKey" integer,
        "LastName" text, "FirstName" text, "Title" text,
        "ReportsToKey" bigint, "BirthDateKey" bigint,
        "HireDateKey" bigint, "GeographyKey" bigint, "Phone" text,
        "Fax" text, "Email" text, "Department" text,
        "Salary" numeric(19,4), "Revision" bigint''',
    'DimCustomer': '''
        "CustomerKey" bigint PRIMARY KEY, "CustomerAlternateKey" integer,
        "FirstName" text, "LastName" text, "Company" text,
        "Phone" text, "Fax" text, "Email" text,
        "GeographyKey" bigint, "SupportRepKey" bigint,
        "ValidFrom" timestamptz, "ValidTo" timestamptz,
        "IsCurrent" integer, "Revision" bigint''',
    'DimAlbum': '''
        "AlbumKey" bigint PRIMARY KEY, "AlbumAlternateKey" integer,
        "Title" text, "ArtistName" text, "Revision" bigint''',
    'DimTrack': '''
        "TrackKey" bigint PRIMARY KEY, "TrackAlternateKey" integer,
        "Name" text, "AlbumKey" bigint, "GenreName" text,
        "MediaTypeName" text, "Composer" text,
        "Milliseconds" integer, "Bytes" bigint, "UnitPrice" numeric(10,2),
        "ValidFrom" timestamptz, "ValidTo" timestamptz,
        "IsCurrent" integer, "Revision" bigint''',
    'DimPlaylist': '''
        "PlaylistKey" bigint PRIMARY KEY, "PlaylistAlternateKey" integer,
        "Name" text, "Revision" bigint''',
    'DimPlaylistTrack': '''
        "PlaylistKey" bigint, "TrackKey" bigint, "IsActive" integer,
        "Revision" bigint, PRIMARY KEY("PlaylistKey", "TrackKey")''',
    'FactInvoice': '''
        "InvoiceLineId" integer PRIMARY KEY, "InvoiceId" integer,
        "CustomerKey" bigint, "TrackKey" bigint,
        "GeographyKey" bigint, "InvoiceDateKey" bigint,
        "UnitPrice" numeric(10,2), "Quantity" integer,
        "Discount" numeric(5,2), "LineTotal" numeric(14,2),
        "IsDeleted" integer, "Revision" bigint'''
}


def main():
    pg = psycopg2.connect(
        host=os.getenv('STAGING_HOST', 'postgres'),
        port=int(os.getenv('STAGING_PORT', '5432')),
        dbname='chinook_staging',
        user=os.getenv('POSTGRES_USER', 'etl_user'),
        password=os.environ['POSTGRES_PASSWORD'],
        connect_timeout=20,
    )
    ch = clickhouse_connect.get_client(
        host=os.getenv('DW_HOST', 'clickhouse'),
        port=int(os.getenv('DW_PORT', '8123')),
        username=os.getenv('CLICKHOUSE_USER', 'etl_user'),
        password=os.environ['CLICKHOUSE_PASSWORD'],
        database='Chinook',
        connect_timeout=20,
        send_receive_timeout=180,
    )
    # Export only current ReplacingMergeTree rows (FINAL); this retains all SCD2
    # dimension versions and preserves deleted facts with IsDeleted=1.
    snapshots = {}
    try:
        for table in SCHEMA:
            final = '' if table == 'DimDate' else ' FINAL'
            order = '`PlaylistKey`,`TrackKey`' if table == 'DimPlaylistTrack' else '`' + {'DimDate':'DateKey','DimGeography':'GeographyKey','DimEmployee':'EmployeeKey','DimCustomer':'CustomerKey','DimAlbum':'AlbumKey','DimTrack':'TrackKey','DimPlaylist':'PlaylistKey','FactInvoice':'InvoiceLineId'}[table] + '`'
            result = ch.query('SELECT * FROM Chinook.`' + table + '`' + final + ' ORDER BY ' + order)
            snapshots[table] = (result.column_names, result.result_rows)
            log.info('Extracted ClickHouse %-19s %d rows', table, len(result.result_rows))
        if len(snapshots['DimDate'][1]) != 33238:
            raise RuntimeError('Incomplete ClickHouse DimDate; refusing to publish snapshot')
        if not snapshots['FactInvoice'][1]:
            raise RuntimeError('FactInvoice empty; refusing to publish snapshot')
        with pg:
            with pg.cursor() as cur:
                cur.execute('CREATE SCHEMA IF NOT EXISTS rpt')
                cur.execute('SELECT pg_advisory_xact_lock(891442110)')
                cur.execute('''CREATE TABLE IF NOT EXISTS rpt._mirror_state (
                    table_name text PRIMARY KEY, signature text NOT NULL,
                    mirrored_at timestamptz NOT NULL DEFAULT now()
                )''')
                signatures = {}
                for table, (columns, rows) in snapshots.items():
                    signatures[table] = hashlib.sha256(json.dumps(
                        [columns, rows], default=str, ensure_ascii=False,
                        separators=(',', ':')).encode()).hexdigest()
                cur.execute('SELECT table_name,signature FROM rpt._mirror_state')
                old = dict(cur.fetchall())
                if all(old.get(k) == v for k,v in signatures.items()):
                    log.info('No ClickHouse DW changes; reporting snapshot already current (0 writes)')
                    return
                for table, ddl in SCHEMA.items():
                    qtable = sql.Identifier('rpt', table)
                    cur.execute(sql.SQL('CREATE TABLE IF NOT EXISTS {} ({})').format(
                        qtable, sql.SQL(ddl)))
                    # Atomic refresh across all tables: any failure rolls everything back.
                    cur.execute(sql.SQL('DELETE FROM {}').format(qtable))
                    columns, rows = snapshots[table]
                    if rows:
                        sql_insert = sql.SQL('INSERT INTO {} ({}) VALUES %s').format(
                            qtable, sql.SQL(', ').join(map(sql.Identifier, columns)))
                        execute_values(cur, sql_insert.as_string(pg), rows, page_size=1000)
                    cur.execute('''INSERT INTO rpt._mirror_state(table_name,signature,mirrored_at)
                        VALUES (%s,%s,now()) ON CONFLICT(table_name) DO UPDATE
                        SET signature=EXCLUDED.signature, mirrored_at=EXCLUDED.mirrored_at''',
                        (table, signatures[table]))
                    log.info('Prepared PostgreSQL rpt.%-19s %d rows', table, len(rows))
                # Grant SELECT on the reporting-only schema, never on staging/ETL.
                cur.execute('GRANT USAGE ON SCHEMA rpt TO grafana_reporting_ro')
                cur.execute('GRANT SELECT ON ALL TABLES IN SCHEMA rpt TO grafana_reporting_ro')
                cur.execute('ALTER DEFAULT PRIVILEGES IN SCHEMA rpt GRANT SELECT ON TABLES TO grafana_reporting_ro')
                cur.execute('SELECT count(*), coalesce(sum("LineTotal"),0) FROM rpt."FactInvoice" WHERE "IsDeleted"=0')
                active, revenue = cur.fetchone()
                if active == 0:
                    raise RuntimeError('No active facts in reporting snapshot')
                log.info('Validation active_facts=%d revenue=%s', active, revenue)
        log.info('SUCCESS: ClickHouse DW mirror published atomically in PostgreSQL rpt schema')
    finally:
        pg.close()
        ch.close()

if __name__ == '__main__':
    main()
