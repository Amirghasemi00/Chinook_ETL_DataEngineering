#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ ! -f .env ]]; then echo "Run bash install.sh first." >&2; exit 1; fi
printf '%s\n' 'Grafana login: http://localhost:3000  username: admin'
grep '^GRAFANA_ADMIN_PASSWORD=' .env
printf '%s\n' 'Kafka is internal-only and does not use a web login in this local demo.'
