#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
DC=(docker compose -f compose.yaml)
[[ -f .env ]] || { echo 'ERROR: .env missing. Run install.sh.' >&2; exit 1; }
[[ ${1:-} == '' || ${1:-} == '--data-only' ]] || { echo 'Usage: bash verify.sh [--data-only]' >&2; exit 2; }
echo '==> Data warehouse and reporting consistency (read-only)'
"${DC[@]}" run --rm --no-deps --entrypoint python etl-runner \
 -u /opt/etl/scripts/verify_data.py
if [[ ${1:-} == '--data-only' ]]; then exit 0; fi
printf '\n==> Kafka broker and topic\n'
"${DC[@]}" exec -T kafka /opt/kafka/bin/kafka-topics.sh \
  --bootstrap-server localhost:9092 --describe --topic chinook.cdc.transactions
printf '\n==> Kafka CDC processes\n'
for service in cdc-producer cdc-consumer; do
  test "$("${DC[@]}" ps --services --status running | grep -cx "$service")" -eq 1 || {
     echo "ERROR: $service not running" >&2; exit 1;
  }
  echo "PASS: $service running"
done
printf '\n==> Grafana API\n'
curl -fsS --max-time 10 http://127.0.0.1:3000/api/health | python3 -m json.tool
printf '\n==> Grafana dashboards\n'
python3 - <<'PY2'
from pathlib import Path
import base64,json,urllib.request
v={}
for line in Path('.env').read_text().splitlines():
    if '=' in line and not line.startswith('#'):
        k,x=line.split('=',1);v[k]=x
headers={'Authorization':'Basic '+base64.b64encode(('admin:'+v['GRAFANA_ADMIN_PASSWORD']).encode()).decode()}
for url in ('/api/datasources/uid/chinook_clickhouse','/api/search?type=dash-db'):
    request=urllib.request.Request('http://127.0.0.1:3000'+url,headers=headers)
    with urllib.request.urlopen(request,timeout=15) as response: data=json.load(response)
    if isinstance(data,list):
        titles=sorted(x.get('title','') for x in data)
        assert 'Sales Overview' in ' '.join(titles) and 'Music' in ' '.join(titles)
        print('PASS: dashboards:',', '.join(titles))
    else:
        assert data.get('uid')=='chinook_clickhouse' and data.get('url')=='postgres:5432'
        print('PASS: reporting datasource')
PY2
printf '\nAll checks passed. Review recent consumer logs to confirm processing.\n'
