#!/usr/bin/env python3
"""Publish SQL Server CDC transactions to Kafka in commit order."""
from __future__ import annotations
import hashlib
import json
import logging
import os
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import pymssql
import psycopg2
from confluent_kafka import Producer
from confluent_kafka.admin import AdminClient, NewTopic

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'cdc'))
from incremental import SOURCE, PK, serializable, lsn_bytes

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger('chinook.kafka.producer')
BROKER = os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'kafka:9092')
TOPIC = os.getenv('KAFKA_TOPIC', 'chinook.cdc.transactions')
INTERVAL = int(os.getenv('CDC_POLL_SECONDS', '5'))


def connect():
    sqlserver = pymssql.connect(
        server=os.getenv('SQLSERVER_HOST', 'sqlserver'),
        user='sa', password=os.environ['MSSQL_SA_PASSWORD'], database='Chinook',
        charset='UTF-8', login_timeout=20, timeout=120,
    )
    sqlserver.autocommit(True)
    pg = psycopg2.connect(
        host=os.getenv('STAGING_HOST', 'postgres'), user='etl_user',
        password=os.environ['POSTGRES_PASSWORD'], dbname='chinook_staging',
        connect_timeout=20,
    )
    return sqlserver, pg


def make_topic():
    admin = AdminClient({'bootstrap.servers': BROKER, 'socket.timeout.ms': 12000})
    existing = admin.list_topics(timeout=15).topics
    if TOPIC in existing and existing[TOPIC].error is None:
        if len(existing[TOPIC].partitions) != 1:
            raise RuntimeError('Kafka CDC topic must have exactly ONE partition to preserve SQL transaction order')
        return
    future = admin.create_topics([NewTopic(TOPIC, num_partitions=1, replication_factor=1,
                                          config={'retention.ms':'604800000'})])[TOPIC]
    try:
        future.result(timeout=30)
        log.info('Created Kafka topic %s (one partition, seven-day retention)', TOPIC)
    except Exception as exc:
        if 'TOPIC_ALREADY_EXISTS' not in str(exc):
            raise


def producer_position(pg):
    with pg.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM etl.pipeline_run WHERE load_kind='full' AND state='completed'")
        if cur.fetchone()[0] != 1:
            raise RuntimeError('Initial full load not completed; will not publish CDC yet')
        cur.execute('''CREATE TABLE IF NOT EXISTS etl.kafka_producer_checkpoint (
          name text PRIMARY KEY,
          last_lsn bytea NOT NULL,
          last_sequence bigint NOT NULL DEFAULT 0,
          updated_at timestamptz NOT NULL DEFAULT now()
        )''')
        # PostgreSQL has bytea ordering operators but no MIN(bytea) aggregate.
        # The producer starts at the earliest of the eleven full-load CDC LSNs.
        cur.execute('''INSERT INTO etl.kafka_producer_checkpoint(name,last_lsn)
            SELECT 'main', last_lsn
            FROM etl.cdc_checkpoint
            WHERE (SELECT COUNT(*) FROM etl.cdc_checkpoint)=11
            ORDER BY last_lsn ASC
            LIMIT 1
            ON CONFLICT DO NOTHING''')
        cur.execute("SELECT last_lsn,last_sequence FROM etl.kafka_producer_checkpoint WHERE name='main' FOR UPDATE")
        row = cur.fetchone()
        if not row: raise RuntimeError('Missing initial full-load CDC checkpoints')
        return lsn_bytes(row[0]), int(row[1])


def deliver(producer, data):
    result = {'error': None, 'done': False}
    def on_delivery(err, message):
        result['error'] = err
        result['done'] = True
    payload=json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')
    if len(payload) > 900_000: raise RuntimeError('CDC transaction exceeds safe Kafka message size; increase broker+producer limits before resuming')
    producer.produce(TOPIC,value=payload,key=data['start_lsn'].encode(),callback=on_delivery)
    remaining = producer.flush(60)
    if remaining or not result['done'] or result['error']:
        raise RuntimeError(f'Kafka delivery not acknowledged: {result}')


def scan(ms, pg, producer):
    with pg.cursor() as pc:
        pc.execute('SELECT pg_try_advisory_lock(98261121)')
        if not pc.fetchone()[0]:
            raise RuntimeError('Another SQL Server CDC Kafka producer is running')
    pg.commit()
    try:
        previous, sequence = producer_position(pg)
        pg.commit()
        mc = ms.cursor()
        mc.execute('SELECT sys.fn_cdc_get_max_lsn()')
        top = lsn_bytes(mc.fetchone()[0])
        if top <= previous:
            return 0
        mc.execute('SELECT sys.fn_cdc_increment_lsn(%s)',(previous,))
        first = lsn_bytes(mc.fetchone()[0])
        batches = defaultdict(list)
        total = 0
        for source_table, destination in SOURCE.items():
            inst = 'dbo_' + source_table
            mc.execute('SELECT sys.fn_cdc_get_min_lsn(%s)',(inst,))
            minimum = lsn_bytes(mc.fetchone()[0])
            if first < minimum:
                raise RuntimeError(f'CDC retention gap for {inst}; stopping rather than losing data')
            if first > top: continue
            mc.execute(f"SELECT * FROM cdc.fn_cdc_get_all_changes_{inst}(%s,%s,'all') ORDER BY __$start_lsn,__$seqval,__$operation", (first,top))
            col = [d[0] for d in mc.description]
            for index, row in enumerate(mc.fetchall()):
                data = dict(zip(col,row))
                operation = int(data['__$operation'])
                if operation not in (1,2,4):
                    raise RuntimeError('Unexpected CDC operation')
                lsn = lsn_bytes(data['__$start_lsn'])
                seqval = lsn_bytes(data['__$seqval'])
                values = {k.lower(): serializable(v) for k,v in data.items() if not k.startswith('__$')}
                key = {key: values[key] for key in PK[destination]}
                fingerprint = json.dumps([inst,lsn.hex(),seqval.hex(),operation,key,values,index],
                                         sort_keys=True,ensure_ascii=False)
                event = {
                    'event_hash': hashlib.sha256(fingerprint.encode()).hexdigest(),
                    'capture_instance': inst,
                    'seqval': seqval.hex(),
                    'operation': operation,
                    'source_key': key,
                    'row_data': values,
                }
                batches[lsn].append(event)
                total += 1
        # A single Kafka partition preserves source transaction ordering.
        for lsn in sorted(batches):
            mc.execute('SELECT sys.fn_cdc_map_lsn_to_time(%s)',(lsn,))
            commit_time = mc.fetchone()[0]
            if commit_time is None:
                raise RuntimeError(f'No SQL Server CDC commit time for LSN {lsn.hex()}')
            if commit_time.tzinfo is None:
                commit_time = commit_time.replace(tzinfo=timezone.utc)
            tx = {
                'version':1, 'kind':'cdc_transaction',
                'sequence':sequence + 1,
                'start_lsn':lsn.hex(), 'commit_time':commit_time.isoformat(),
                'events':sorted(batches[lsn],key=lambda e:(e['seqval'],e['capture_instance'],e['event_hash'])),
            }
            deliver(producer,tx)
            # Persist after Kafka ack: a crash between ack and this commit
            # re-sends the same sequence, which is safe to deduplicate.
            with pg.cursor() as pc:
                pc.execute('''UPDATE etl.kafka_producer_checkpoint
                   SET last_lsn=%s,last_sequence=%s,updated_at=now()
                   WHERE name='main' AND last_sequence=%s''',
                   (psycopg2.Binary(lsn),sequence+1,sequence))
                if pc.rowcount != 1: raise RuntimeError('Kafka producer sequence checkpoint conflict')
            pg.commit()
            sequence += 1
            log.info('Published seq=%d transaction LSN=%s events=%d',sequence,lsn.hex(),len(tx['events']))
        # The producer's position may lead the consumer's position: Kafka owns
        # the intervening durable messages. Never advance before Kafka ack.
        with pg.cursor() as pc:
            pc.execute('''UPDATE etl.kafka_producer_checkpoint SET last_lsn=%s,updated_at=now()
                         WHERE name='main' AND last_lsn<=%s''',
                       (psycopg2.Binary(top),psycopg2.Binary(top)))
        pg.commit()
        if total: log.info('CDC scan published %d events in %d Kafka transactions',total,len(batches))
        return total
    finally:
        pg.rollback()
        try:
            with pg.cursor() as pc: pc.execute('SELECT pg_advisory_unlock(98261121)')
            pg.commit()
        except Exception: pg.rollback()


def main():
    make_topic()
    producer=Producer({'bootstrap.servers':BROKER, 'enable.idempotence':True,
                       'acks':'all','message.timeout.ms':90000,
                       'retries':1000000,'socket.timeout.ms':15000})
    log.info('Native SQL Server CDC -> Kafka producer started; poll=%ds',INTERVAL)
    while True:
        ms=pg=None
        try:
            ms,pg=connect()
            scan(ms,pg,producer)
        except Exception:
            log.exception('CDC scan/publish failed; retrying (no offsets were skipped)')
            time.sleep(10)
        finally:
            if pg: pg.close()
            if ms: ms.close()
        time.sleep(INTERVAL)

if __name__=='__main__': main()
