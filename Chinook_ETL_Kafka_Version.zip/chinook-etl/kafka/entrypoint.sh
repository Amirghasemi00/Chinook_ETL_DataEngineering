#!/usr/bin/env sh
# Kafka KRaft single-node broker; logs and metadata are on a named Docker volume.
set -eu
: "${CLUSTER_ID:?CLUSTER_ID is required}"
: "${KAFKA_NODE_ID:?KAFKA_NODE_ID is required}"
: "${KAFKA_CONTROLLER_QUORUM_VOTERS:?KAFKA_CONTROLLER_QUORUM_VOTERS is required}"

# These environment variables are owned by our Compose file, not arbitrary input.
# A local, disposable server.properties file is built at every startup.
cat > /etc/kafka/server.properties <<EOF
node.id=${KAFKA_NODE_ID}
process.roles=${KAFKA_PROCESS_ROLES:-broker,controller}
listeners=${KAFKA_LISTENERS:-PLAINTEXT://:9092,CONTROLLER://:9093}
advertised.listeners=${KAFKA_ADVERTISED_LISTENERS:-PLAINTEXT://kafka:9092}
listener.security.protocol.map=${KAFKA_LISTENER_SECURITY_PROTOCOL_MAP:-PLAINTEXT:PLAINTEXT,CONTROLLER:PLAINTEXT}
controller.quorum.voters=${KAFKA_CONTROLLER_QUORUM_VOTERS}
controller.listener.names=${KAFKA_CONTROLLER_LISTENER_NAMES:-CONTROLLER}
inter.broker.listener.name=${KAFKA_INTER_BROKER_LISTENER_NAME:-PLAINTEXT}
offsets.topic.replication.factor=${KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR:-1}
transaction.state.log.replication.factor=${KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR:-1}
transaction.state.log.min.isr=${KAFKA_TRANSACTION_STATE_LOG_MIN_ISR:-1}
group.initial.rebalance.delay.ms=${KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS:-0}
num.partitions=${KAFKA_NUM_PARTITIONS:-1}
log.dirs=${KAFKA_LOG_DIRS:-/var/lib/kafka/data}
EOF

# Never reformat an existing data volume or change its cluster identity.
if [ ! -f /var/lib/kafka/data/meta.properties ]; then
    if [ -n "$(ls -A /var/lib/kafka/data)" ]; then
        echo 'Kafka data volume is nonempty but meta.properties is absent; refusing to initialize it.' >&2
        exit 1
    fi
    /opt/kafka/bin/kafka-storage.sh format \
      --cluster-id "$CLUSTER_ID" --config /etc/kafka/server.properties
fi
exec /opt/kafka/bin/kafka-server-start.sh /etc/kafka/server.properties
