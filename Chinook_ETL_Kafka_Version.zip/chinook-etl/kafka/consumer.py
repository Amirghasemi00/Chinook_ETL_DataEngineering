#!/usr/bin/env python3
"""Apply Kafka CDC transactions to staging, the warehouse and reporting."""
from __future__ import annotations
import json
import logging
import os
import sys
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import clickhouse_connect
import psycopg2
from psycopg2.extras import Json
from confluent_kafka import Consumer, KafkaException

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'cdc'))
sys.path.insert(0,str(ROOT/'reporting'))
from incremental import (SOURCE, ensure_completed_full_load, ensure_revisions,
                         stage_group, reconcile, validate, lsn_bytes, as_timestamp)
from sync_dw import main as sync_reporting

logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
log=logging.getLogger('chinook.kafka.consumer')
BROKER=os.getenv('KAFKA_BOOTSTRAP_SERVERS','kafka:9092')
TOPIC=os.getenv('KAFKA_TOPIC','chinook.cdc.transactions')


def check_tx(tx):
    if tx.get('version') != 1 or tx.get('kind')!='cdc_transaction':
        raise ValueError('Unsupported Kafka CDC message version/type')
    seq=tx.get('sequence')
    if not isinstance(seq,int) or seq < 1:
        raise ValueError('Missing or invalid Kafka CDC sequence number')
    lsn=bytes.fromhex(tx['start_lsn'])
    if len(lsn)!=10: raise ValueError('Invalid CDC transaction LSN')
    at=as_timestamp(datetime.fromisoformat(tx['commit_time']))
    if not isinstance(tx.get('events'),list) or not tx['events']:
        raise ValueError('CDC transaction must contain at least one event')
    for event in tx['events']:
        if event['capture_instance'] not in {f'dbo_{t}' for t in SOURCE}:
            raise ValueError('Unknown source table')
        if event['operation'] not in (1,2,4):
            raise ValueError('Unknown CDC operation')
        if len(bytes.fromhex(event['seqval'])) != 10:
            raise ValueError('Invalid CDC seqval')
        if not isinstance(event['source_key'],dict) or not isinstance(event['row_data'],dict):
            raise ValueError('Malformed CDC record')
    return lsn,at


def connect():
    pg=psycopg2.connect(host=os.getenv('STAGING_HOST','postgres'),
          user='etl_user',password=os.environ['POSTGRES_PASSWORD'],
          dbname='chinook_staging',connect_timeout=20)
    ch=clickhouse_connect.get_client(host=os.getenv('DW_HOST','clickhouse'),
          port=int(os.getenv('DW_PORT','8123')),username='etl_user',
          password=os.environ['CLICKHOUSE_PASSWORD'],database='Chinook',
          connect_timeout=20,send_receive_timeout=120)
    return pg,ch


def apply_message(tx):
    lsn, at=check_tx(tx)
    pg=ch=None
    try:
        pg,ch=connect()
        with pg.cursor() as pc:
            pc.execute('SELECT pg_try_advisory_lock(98261120)')
            if not pc.fetchone()[0]:
                raise RuntimeError('Another incremental warehouse writer is active')
        pg.commit()
        ckpt=ensure_completed_full_load(pg,ch)
        # Detect topic-retention gaps rather than silently losing CDC events.
        with pg.cursor() as pc:
            pc.execute('''CREATE TABLE IF NOT EXISTS etl.kafka_consumer_checkpoint (
                name text PRIMARY KEY,
                last_sequence bigint NOT NULL DEFAULT 0,
                updated_at timestamptz NOT NULL DEFAULT now()
            )''')
            pc.execute("INSERT INTO etl.kafka_consumer_checkpoint(name,last_sequence) VALUES ('main',0) ON CONFLICT DO NOTHING")
            pc.execute("SELECT last_sequence FROM etl.kafka_consumer_checkpoint WHERE name='main' FOR UPDATE")
            last_sequence=int(pc.fetchone()[0])
        pg.commit()
        if tx['sequence'] > last_sequence + 1:
            raise RuntimeError('Kafka CDC sequence gap; refusing to skip missing events')
        is_duplicate=tx['sequence'] <= last_sequence
        if is_duplicate:
            # This message already reached the reporting mirror before the
            # offset was acknowledged. It can be committed after a safe check.
            sync_reporting()
            log.info('Already applied Kafka sequence %d; mirror verified',tx['sequence'])
            return
        with pg.cursor() as pc:
            pc.execute("INSERT INTO etl.pipeline_run(load_kind,state,notes) VALUES ('incremental','running','Kafka transaction') RETURNING run_id")
            run_id=pc.fetchone()[0]
            for e in tx['events']:
                pc.execute('''INSERT INTO etl.cdc_events
                   (event_hash,capture_instance,start_lsn,seqval,operation,
                    source_key,row_data,commit_time)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT(event_hash) DO NOTHING''',
                   (e['event_hash'],e['capture_instance'],psycopg2.Binary(lsn),
                    psycopg2.Binary(bytes.fromhex(e['seqval'])),e['operation'],
                    Json(e['source_key']),Json(e['row_data']),at))
        pg.commit() # Kafka payload durable in PostgreSQL before any DW writes
        ensure_revisions(pg)
        with pg.cursor() as pc:
            pc.execute('''SELECT event_id,capture_instance,start_lsn,seqval,operation,
                        source_key,row_data,commit_time
                        FROM etl.cdc_events WHERE applied_at IS NULL
                        ORDER BY start_lsn,seqval,event_id''')
            pending=[dict(zip(['event_id','capture_instance','start_lsn','seqval',
                               'operation','source_key','row_data','commit_time'],row)) for row in pc.fetchall()]
        groups=defaultdict(list)
        for event in pending: groups[lsn_bytes(event['start_lsn'])].append(event)
        for group_lsn, group in groups.items():
            try:
                times={e['commit_time'] for e in group}
                if len(times)!=1: raise RuntimeError('Different timestamps within one transaction')
                with pg.cursor() as pc:
                    pc.execute('SELECT revision FROM etl.cdc_revision WHERE start_lsn=%s',
                               (psycopg2.Binary(group_lsn),))
                    rev=int(pc.fetchone()[0])+1
                stage_group(pg,group)
                reconcile(pg,ch,rev,group_lsn,as_timestamp(next(iter(times))))
                validate(pg,ch)
                with pg.cursor() as pc:
                    pc.execute('UPDATE etl.cdc_events SET applied_at=now() WHERE event_id=ANY(%s)',
                               ([e['event_id'] for e in group],))
                pg.commit()
            except Exception:
                pg.rollback(); raise
        with pg.cursor() as pc:
            pc.execute('SELECT count(*) FROM etl.cdc_events WHERE applied_at IS NULL')
            if pc.fetchone()[0]: raise RuntimeError('Unapplied CDC events remain; Kafka offset will not commit')
            for inst in ckpt:
                pc.execute('''UPDATE etl.cdc_checkpoint SET last_lsn=%s,updated_at=now()
                    WHERE capture_instance=%s AND last_lsn<=%s''',
                    (psycopg2.Binary(lsn),inst,psycopg2.Binary(lsn)))
            pc.execute("UPDATE etl.pipeline_run SET state='completed',finished_at=now(),notes=%s WHERE run_id=%s",
                       (f"Kafka events={len(tx['events'])}; new pending applied={len(pending)}",run_id))
        pg.commit()
        # Mirror is the final commit prerequisite for Kafka offset acknowledgement.
        sync_reporting()
        with pg.cursor() as pc:
            pc.execute('''UPDATE etl.kafka_consumer_checkpoint
                SET last_sequence=%s,updated_at=now()
                WHERE name='main' AND last_sequence=%s''',
                (tx['sequence'],tx['sequence']-1))
            if pc.rowcount != 1: raise RuntimeError('Consumer Kafka sequence conflict')
        pg.commit()
        log.info('Applied Kafka CDC transaction %s (events=%d; new pending=%d); mirror current',
                 lsn.hex(),len(tx['events']),len(pending))
    finally:
        if ch: ch.close()
        if pg: pg.close()


def main():
    consumer=Consumer({'bootstrap.servers':BROKER,'group.id':'chinook-dw-kafka-v1',
                       'enable.auto.commit':False,'auto.offset.reset':'earliest',
                       'max.poll.interval.ms':900000,'session.timeout.ms':45000})
    consumer.subscribe([TOPIC])
    log.info('Kafka CDC consumer started on topic %s',TOPIC)
    try:
        while True:
            msg=consumer.poll(3)
            if msg is None: continue
            if msg.error():
                log.error('Kafka consumer: %s',msg.error())
                time.sleep(5);continue
            try:
                tx=json.loads(msg.value())
                apply_message(tx)
                consumer.commit(message=msg,asynchronous=False)
                log.info('Committed Kafka topic=%s partition=%d offset=%d',
                         msg.topic(),msg.partition(),msg.offset())
            except Exception:
                # Fail and let Compose restart us. Kafka will redeliver the
                # uncommitted message; the PostgreSQL inbox makes it safe.
                log.exception('Kafka message NOT committed; restarting consumer for safe retry')
                raise
    finally:
        consumer.close()

if __name__=='__main__':main()
