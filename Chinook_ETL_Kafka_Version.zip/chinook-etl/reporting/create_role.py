#!/usr/bin/env python3
"""Idempotently provision a read-only PostgreSQL login (no secrets printed)."""
import os
import psycopg2
from psycopg2 import sql

pw = os.environ['GRAFANA_REPORT_PASSWORD']
assert len(pw) >= 24, 'GRAFANA_REPORT_PASSWORD too short'
con = psycopg2.connect(
    host=os.getenv('STAGING_HOST','postgres'),
    port=int(os.getenv('STAGING_PORT','5432')),
    user=os.getenv('POSTGRES_USER','etl_user'),
    password=os.environ['POSTGRES_PASSWORD'],
    dbname='chinook_staging',connect_timeout=20)
with con:
    with con.cursor() as cur:
        cur.execute("SELECT 1 FROM pg_roles WHERE rolname='grafana_reporting_ro'")
        if cur.fetchone() is None:
            cur.execute('CREATE ROLE grafana_reporting_ro LOGIN')
        cur.execute('ALTER ROLE grafana_reporting_ro WITH LOGIN PASSWORD %s', (pw,))
        cur.execute('GRANT CONNECT ON DATABASE chinook_staging TO grafana_reporting_ro')
        # Explicitly do NOT grant login access to staging/etl schemas.
con.close()
print('PASS: dedicated PostgreSQL reporting login ready (password hidden)')
