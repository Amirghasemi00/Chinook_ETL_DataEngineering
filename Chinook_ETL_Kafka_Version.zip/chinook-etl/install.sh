#!/usr/bin/env bash
# Install or resume the Chinook ETL stack without deleting its volumes.
set -Eeuo pipefail
umask 077
cd "$(dirname "${BASH_SOURCE[0]}")"
ROOT="$PWD"
DC=(docker compose -f "$ROOT/compose.yaml")
log() { printf '\n==> %s\n' "$*"; }
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
trap 'echo "INSTALL STOPPED at line $LINENO. Docker volumes were not deleted. Inspect error and rerun." >&2' ERR
[[ ${1:-} == '' || ${1:-} == '--rebuild' ]] || die 'Usage: bash install.sh [--rebuild]'
REBUILD=false
[[ ${1:-} == '--rebuild' ]] && REBUILD=true
[[ -f compose.yaml && -f sqlserver/setup/seed_data.sql && -f kafka/consumer.py ]] || die 'Incomplete Kafka project.'
command -v python3 >/dev/null || die 'Python3 required'
command -v curl >/dev/null || die 'curl required'
command -v docker >/dev/null || die 'Docker required'
docker compose version >/dev/null 2>&1 || die 'Docker Compose v2 required'
docker info >/dev/null 2>&1 || die 'Docker daemon unavailable'
if [[ ! -f .env ]] && docker volume ls --format '{{.Name}}' | grep -Eq '^chinook-etl-kafka_(sqlserver_data|postgres_data|clickhouse_data|kafka_data|chinook_grafana_data)$'; then
  die 'Existing Kafka volumes found but .env absent: restore the original .env from backup (do NOT generate new passwords).'
fi
python3 scripts/create_env.py
"${DC[@]}" config --quiet
if [[ -z "$("${DC[@]}" ps -aq 2>/dev/null)" ]]; then
 python3 - <<'PY'
import socket
busy=[]
for port in (1433,5432,8123,9000,3000):
    s=socket.socket()
    try:s.bind(('127.0.0.1',port))
    except OSError:busy.append(port)
    finally:s.close()
if busy:raise SystemExit(f'Host ports {busy} occupied; stop the old Airflow stack using docker compose stop in its own folder. No data should be deleted.')
PY
fi
image_ensure() {
  local service="$1" image="$2"
  if $REBUILD || ! docker image inspect "$image" >/dev/null 2>&1; then
    log "Building $service image"
    "${DC[@]}" build "$service"
  else
    echo "Reusing cached image: $image"
  fi
}
log 'Pulling base database images if needed'
for img in mcr.microsoft.com/mssql/server:2022-latest public.ecr.aws/docker/library/postgres:16; do
  docker image inspect "$img" >/dev/null 2>&1 || docker pull "$img"
done
image_ensure clickhouse 'chinook-clickhouse:portable-local'
image_ensure etl-runner 'chinook-etl-python:kafka-local'
# Resolve once after the .env auto-repair; default avoids blocked Docker registries.
kafka_image="$(python3 - <<'PYIMG'
from pathlib import Path
v = None
for raw in Path('.env').read_text().splitlines():
    if raw.strip() and not raw.lstrip().startswith('#'):
        k, sep, value = raw.partition('=')
        if k == 'KAFKA_IMAGE': v = value.strip().strip('\"\'')
print(v or 'chinook-kafka:4.3.1-local')
PYIMG
)"
if [[ "$kafka_image" == 'chinook-kafka:4.3.1-local' ]]; then
  image_ensure kafka 'chinook-kafka:4.3.1-local'
elif docker image inspect "$kafka_image" >/dev/null 2>&1; then
  log "Using explicit cached Kafka image: $kafka_image"
else
  die "Custom KAFKA_IMAGE=$kafka_image not cached. Use the local default (remove KAFKA_IMAGE from .env), or pull it separately."
fi
log 'Starting SQL Server, PostgreSQL and ClickHouse with independent Kafka-project volumes'
"${DC[@]}" up -d --no-deps --pull never sqlserver
"${DC[@]}" up -d --wait --no-deps --pull never postgres clickhouse
sql_chinook_exists() {
 "${DC[@]}" exec -T sqlserver /bin/bash -lc '
  set -euo pipefail
  if [[ -x /opt/mssql-tools18/bin/sqlcmd ]]; then c=/opt/mssql-tools18/bin/sqlcmd
  elif [[ -x /opt/mssql-tools/bin/sqlcmd ]]; then c=/opt/mssql-tools/bin/sqlcmd
  else exit 127; fi
  export SQLCMDPASSWORD="${MSSQL_SA_PASSWORD:?}"
  exec "$c" -S localhost -U sa -C -b -h -1 -W -l 5 -Q "SET NOCOUNT ON; SELECT CASE WHEN DB_ID(N'\''Chinook'\'') IS NULL THEN 0 ELSE 1 END;"
 ' | tr -d '\r[:space:]'
}
sql_source_valid() {
 "${DC[@]}" exec -T sqlserver /bin/bash -lc '
  set -euo pipefail
  if [[ -x /opt/mssql-tools18/bin/sqlcmd ]]; then c=/opt/mssql-tools18/bin/sqlcmd
  elif [[ -x /opt/mssql-tools/bin/sqlcmd ]]; then c=/opt/mssql-tools/bin/sqlcmd
  else exit 127; fi
  export SQLCMDPASSWORD="${MSSQL_SA_PASSWORD:?}"
  exec "$c" -S localhost -U sa -C -b -h -1 -W -l 5 -d Chinook -Q "SET NOCOUNT ON; SELECT CASE WHEN (SELECT COUNT(*) FROM cdc.change_tables) = 11 AND (SELECT COUNT(*) FROM dbo.InvoiceLine) > 0 THEN 1 ELSE 0 END;"
 ' | tr -d '\r[:space:]'
}
log 'Checking SQL Server Chinook source'
ready=''
for _ in {1..60}; do
  if ready="$(sql_chinook_exists 2>/dev/null)" && [[ "$ready" == '0' || "$ready" == '1' ]]; then break; fi
  sleep 3
done
[[ "$ready" == '0' || "$ready" == '1' ]] || die 'SQL Server not ready; inspect docker compose logs sqlserver'
if [[ "$ready" == '0' ]]; then
  log 'Initial installation: loading Chinook sample rows and enabling SQL Server CDC'
  bash sqlserver/setup/run_install.sh
else
  echo 'Existing SQL Server Chinook found; skipping source inserts.'
fi
[[ "$(sql_source_valid)" == '1' ]] || die 'SQL Server CDC or source incomplete; refusing to reinitialize data.'
log 'Preparing staging and warehouse schemas (idempotent)'
bash database_setup/run_setup.sh
completed="$("${DC[@]}" exec -T postgres sh -lc \
  'psql -X -v ON_ERROR_STOP=1 -At -U "$POSTGRES_USER" -d chinook_staging -c "SELECT count(*) FROM etl.pipeline_run WHERE load_kind='\''full'\'' AND state='\''completed'\''"' | tr -d '\r[:space:]')"
[[ "$completed" =~ ^[0-9]+$ && "$completed" -le 1 ]] || die 'Unsafe Full Load state.'
if [[ "$completed" == '0' ]]; then
  log 'ONE-TIME full load: SQL Server -> PostgreSQL staging -> ClickHouse'
  echo 'Do not modify SQL Server while the initial load is in progress.'
  "${DC[@]}" run --rm --no-deps --entrypoint python etl-runner -u /opt/etl/full_load/full_load.py
else
  echo 'Full Load already completed. Preserving 11 CDC LSN checkpoints.'
fi
log 'Configuring reporting mirror and Grafana login'
"${DC[@]}" run --rm --no-deps --entrypoint python etl-runner -u /opt/etl/reporting/create_role.py
"${DC[@]}" run --rm --no-deps --entrypoint python etl-runner -u /opt/etl/reporting/sync_dw.py
image_ensure chinook-grafana 'chinook-grafana:13.3.1-portable-local'
"${DC[@]}" up -d --no-deps --pull never chinook-grafana
log 'Starting Apache Kafka KRaft (single-node classroom broker)'
"${DC[@]}" up -d --no-deps --pull never kafka || die 'Kafka could not start. Inspect docker compose logs kafka.'
kafka_ready=false
for _ in {1..60}; do
 if "${DC[@]}" exec -T kafka /opt/kafka/bin/kafka-broker-api-versions.sh --bootstrap-server localhost:9092 >/dev/null 2>&1; then
   kafka_ready=true;break
 fi
 sleep 5
done
$kafka_ready || die 'Kafka did not become ready. Check docker compose logs kafka.'
log 'Verifying baseline before starting CDC producer and consumer'
bash verify.sh --data-only
log 'Starting Kafka CDC producer and consumer'
"${DC[@]}" up -d --no-deps --pull never cdc-producer
# The producer creates the ordered transaction topic.
topic_ready=false
for _ in {1..50}; do
 if "${DC[@]}" exec -T kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 \
     --describe --topic chinook.cdc.transactions >/dev/null 2>&1; then topic_ready=true;break;fi
 sleep 3
done
$topic_ready || die 'Kafka producer did not create CDC topic. Check docker compose logs cdc-producer.'
"${DC[@]}" up -d --no-deps --pull never cdc-consumer
log 'Checking Grafana HTTP API'
grafana_ready=false
for _ in {1..60}; do
 if curl -fsS --max-time 5 http://127.0.0.1:3000/api/health >/dev/null 2>&1; then grafana_ready=true;break;fi
 sleep 3
done
$grafana_ready || die 'Grafana not ready; check docker compose logs chinook-grafana'
log 'Final verification'
bash verify.sh
printf 'Installed on %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > .install_complete
chmod 600 .install_complete
log 'Chinook ETL is running; databases are stored in Docker volumes'
"${DC[@]}" ps
printf '\nGrafana: http://localhost:3000 (username admin; password: bash secrets-help.sh)\n'
printf 'Kafka topic: chinook.cdc.transactions; worker logs: docker compose logs -f cdc-producer cdc-consumer\n'
printf 'Never use docker compose down -v or docker volume prune.\n'
