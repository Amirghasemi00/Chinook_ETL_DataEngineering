#!/usr/bin/env python3
"""Create private .env once; auto-repair legacy Kafka image config only.

Do not reset passwords or delete volumes. A repair creates a private backup.
Any duplicate OTHER than KAFKA_IMAGE remains a hard error.
"""
from pathlib import Path
import os
import secrets

root = Path(__file__).resolve().parent.parent
path = root / '.env'
LOCAL_KAFKA = 'chinook-kafka:4.3.1-local'
BLOCKED_IMAGES = {
    'apache/kafka:4.3.1',
    'docker.io/apache/kafka:4.3.1',
    'mirror.gcr.io/apache/kafka:4.3.1',
}
required = [
    'MSSQL_SA_PASSWORD', 'POSTGRES_PASSWORD', 'CLICKHOUSE_PASSWORD',
    'GRAFANA_REPORT_PASSWORD', 'GRAFANA_ADMIN_PASSWORD',
    'GRAFANA_SECRET_KEY',
]


def protect_and_repair():
    original = path.read_text()
    lines = original.splitlines(keepends=True)
    values, image_positions = {}, []
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        if '=' not in line:
            raise SystemExit('Malformed .env line; refusing to change existing secrets')
        key, val = line.strip().split('=', 1)
        if key == 'KAFKA_IMAGE':
            image_positions.append(index)
        elif key in values:
            raise SystemExit(f'Duplicate variable {key} in .env; refusing to change secrets')
        values[key] = val
    missing = [key for key in required if not values.get(key)]
    if missing:
        raise SystemExit('Existing .env incomplete; no passwords changed. Missing: ' + ', '.join(missing))
    if len(image_positions) > 1 or values.get('KAFKA_IMAGE', '').strip("\"'") in BLOCKED_IMAGES:
        # Existing .env has a known broken image or duplicate overrides.
        # Delete only KAFKA_IMAGE assignments; Compose defaults to the local build.
        fixed = ''.join(line for i, line in enumerate(lines) if i not in image_positions)
        backup = root / ('.env.kafka-fix-' + secrets.token_hex(6) + '.bak')
        with backup.open('x') as out:
            out.write(original)
        backup.chmod(0o600)
        tmp = root / ('.env.repair-' + secrets.token_hex(6))
        try:
            with tmp.open('x') as out:
                out.write(fixed)
            tmp.chmod(0o600)
            os.replace(tmp, path)
        finally:
            if tmp.exists():
                tmp.unlink()
        print('Repaired Kafka image setting only. All credentials preserved; private .env backup created.')
    else:
        print('Existing .env retained unchanged (values hidden)')
    path.chmod(0o600)


if path.is_symlink():
    raise SystemExit('Refusing to follow .env symlink')
if path.exists():
    protect_and_repair()
else:
    values = {
        'MSSQL_SA_PASSWORD': 'A' + secrets.token_hex(24) + '!z9',
        'POSTGRES_PASSWORD': secrets.token_hex(24),
        'CLICKHOUSE_PASSWORD': secrets.token_hex(24),
        'GRAFANA_REPORT_PASSWORD': secrets.token_hex(24),
        'GRAFANA_ADMIN_PASSWORD': secrets.token_hex(24),
        'GRAFANA_SECRET_KEY': secrets.token_hex(32),
    }
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write('# Generated once by install.sh. NEVER commit or share this file.\n')
        f.writelines(f'{k}={v}\n' for k, v in values.items())
    print('Created private .env (values hidden)')
