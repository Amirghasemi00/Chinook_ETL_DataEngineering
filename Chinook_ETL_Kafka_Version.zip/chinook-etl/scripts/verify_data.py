#!/usr/bin/env python3
"""Read-only cross-system row-count and revenue parity audit."""
import os
from decimal import Decimal
import clickhouse_connect
import psycopg2

ch = clickhouse_connect.get_client(
    host=os.getenv('DW_HOST', 'clickhouse'),
    port=int(os.getenv('DW_PORT', '8123')),
    username=os.getenv('CLICKHOUSE_USER', 'etl_user'),
    password=os.environ['CLICKHOUSE_PASSWORD'],
    database='Chinook',
    connect_timeout=20,
    send_receive_timeout=120,
)
pg = psycopg2.connect(
    host=os.getenv('STAGING_HOST', 'postgres'),
    user=os.getenv('POSTGRES_USER', 'etl_user'),
    password=os.environ['POSTGRES_PASSWORD'],
    database='chinook_staging', connect_timeout=20,
)
tables = ['DimDate', 'DimGeography', 'DimEmployee', 'DimCustomer',
          'DimAlbum', 'DimTrack', 'DimPlaylist', 'DimPlaylistTrack', 'FactInvoice']
try:
    with pg.cursor() as cur:
        cur.execute("SELECT count(*) FROM etl.pipeline_run WHERE load_kind='full' AND state='completed'")
        runs = cur.fetchone()[0]
        assert runs == 1, f'Expected one completed Full Load, found {runs}'
        cur.execute('SELECT count(*) FROM etl.cdc_checkpoint')
        assert cur.fetchone()[0] == 11, 'Missing CDC LSN checkpoints'
        print('PASS: Full Load completed exactly once; 11 CDC checkpoints present')
        for t in tables:
            final = '' if t == 'DimDate' else ' FINAL'
            ch_count = ch.query(f'SELECT count() FROM Chinook.`{t}`{final}').result_rows[0][0]
            cur.execute(f'SELECT count(*) FROM rpt."{t}"')
            pg_count = cur.fetchone()[0]
            assert ch_count == pg_count, f'{t}: ClickHouse={ch_count} PostgreSQL mirror={pg_count}'
            print(f'PASS: {t:19s} {ch_count:6d} rows agree')
        cur.execute('SELECT count(*), coalesce(sum("LineTotal"),0) FROM rpt."FactInvoice" WHERE "IsDeleted"=0')
        pg_count, pg_sales = cur.fetchone()
        ch_count, ch_sales = ch.query('SELECT count(),sum(LineTotal) FROM Chinook.FactInvoice FINAL WHERE IsDeleted=0').result_rows[0]
        assert pg_count == ch_count, f'Active fact counts differ: CH={ch_count}, PG={pg_count}'
        assert Decimal(str(pg_sales)) == Decimal(str(ch_sales)), f'Revenue differs: CH={ch_sales}, PG={pg_sales}'
        assert pg_count > 0
        print(f'PASS: Active invoice lines={pg_count}; sales={pg_sales} (identical CH and PG)')
        if pg_count == 2240 and Decimal(str(pg_sales)) == Decimal('73123.94'):
            print('PASS: Original seed baseline matches 2240 / 73123.94')
        else:
            print('NOTE: Counts differ from initial seed, but ClickHouse and reporting agree (possible legitimate CDC changes)')
finally:
    pg.close()
    ch.close()
