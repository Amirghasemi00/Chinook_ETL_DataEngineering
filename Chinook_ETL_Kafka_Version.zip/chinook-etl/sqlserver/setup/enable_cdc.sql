-- Enable native SQL Server CDC after schema + data + FK validation.
-- Requires SQL Server Agent enabled in the SQL Server Linux container.
-- All change operations retained (supports_net_changes=0).
USE [Chinook];
GO
IF (SELECT is_cdc_enabled FROM sys.databases WHERE name = N'Chinook') = 0
BEGIN
    EXEC sys.sp_cdc_enable_db;
END;
GO

DECLARE @source_table sysname;
DECLARE source_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT t.table_name FROM (VALUES
        (N'Album'),
        (N'Artist'),
        (N'Customer'),
        (N'Employee'),
        (N'Genre'),
        (N'Invoice'),
        (N'InvoiceLine'),
        (N'MediaType'),
        (N'Playlist'),
        (N'PlaylistTrack'),
        (N'Track')
    ) AS t(table_name);

OPEN source_tables;
FETCH NEXT FROM source_tables INTO @source_table;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF OBJECT_ID(N'dbo.' + QUOTENAME(@source_table), N'U') IS NULL
    BEGIN
        DECLARE @error nvarchar(2048) = CONCAT(N'Missing source table dbo.', @source_table);
        CLOSE source_tables;
        DEALLOCATE source_tables;
        THROW 51001, @error, 1;
    END;
    IF NOT EXISTS (
        SELECT 1
        FROM sys.tables
        WHERE schema_id = SCHEMA_ID(N'dbo')
          AND name = @source_table
          AND is_tracked_by_cdc = 1
    )
    BEGIN
        EXEC sys.sp_cdc_enable_table
            @source_schema = N'dbo',
            @source_name = @source_table,
            @role_name = NULL,
            @supports_net_changes = 0;
    END;
    FETCH NEXT FROM source_tables INTO @source_table;
END;
CLOSE source_tables;
DEALLOCATE source_tables;
GO

-- Verification: 11 sources should have is_tracked_by_cdc=1; dbo.Test should be 0.
SELECT DB_NAME() AS database_name,
       (SELECT is_cdc_enabled FROM sys.databases WHERE name = DB_NAME()) AS database_cdc_enabled;
SELECT name AS table_name, is_tracked_by_cdc
FROM sys.tables
ORDER BY name;
SELECT name AS cdc_job_name, enabled
FROM msdb.dbo.sysjobs
WHERE name LIKE N'cdc.Chinook%';
GO
