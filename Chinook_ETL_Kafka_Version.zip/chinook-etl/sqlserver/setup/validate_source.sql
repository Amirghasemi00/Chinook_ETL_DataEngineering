-- Chinook source verification after enabling CDC. Read-only except THROW on mismatches.
USE [Chinook];
GO
SET NOCOUNT ON;
DECLARE @Expected TABLE (TableName sysname PRIMARY KEY, ExpectedRows bigint);
INSERT INTO @Expected(TableName,ExpectedRows) VALUES
    (N'Album', CONVERT(bigint,347)),
    (N'Artist', CONVERT(bigint,275)),
    (N'Customer', CONVERT(bigint,59)),
    (N'Employee', CONVERT(bigint,10)),
    (N'Genre', CONVERT(bigint,25)),
    (N'Invoice', CONVERT(bigint,412)),
    (N'InvoiceLine', CONVERT(bigint,2240)),
    (N'MediaType', CONVERT(bigint,5)),
    (N'Playlist', CONVERT(bigint,18)),
    (N'PlaylistTrack', CONVERT(bigint,8715)),
    (N'Test', CONVERT(bigint,6)),
    (N'Track', CONVERT(bigint,3503));
DECLARE @Actual TABLE (TableName sysname PRIMARY KEY, ActualRows bigint);
INSERT INTO @Actual(TableName,ActualRows)
SELECT N'Album', COUNT_BIG(*) FROM dbo.[Album]
UNION ALL
SELECT N'Artist', COUNT_BIG(*) FROM dbo.[Artist]
UNION ALL
SELECT N'Customer', COUNT_BIG(*) FROM dbo.[Customer]
UNION ALL
SELECT N'Employee', COUNT_BIG(*) FROM dbo.[Employee]
UNION ALL
SELECT N'Genre', COUNT_BIG(*) FROM dbo.[Genre]
UNION ALL
SELECT N'Invoice', COUNT_BIG(*) FROM dbo.[Invoice]
UNION ALL
SELECT N'InvoiceLine', COUNT_BIG(*) FROM dbo.[InvoiceLine]
UNION ALL
SELECT N'MediaType', COUNT_BIG(*) FROM dbo.[MediaType]
UNION ALL
SELECT N'Playlist', COUNT_BIG(*) FROM dbo.[Playlist]
UNION ALL
SELECT N'PlaylistTrack', COUNT_BIG(*) FROM dbo.[PlaylistTrack]
UNION ALL
SELECT N'Test', COUNT_BIG(*) FROM dbo.[Test]
UNION ALL
SELECT N'Track', COUNT_BIG(*) FROM dbo.[Track];
SELECT e.TableName, e.ExpectedRows, a.ActualRows,
       CASE WHEN a.ActualRows=e.ExpectedRows THEN N'OK' ELSE N'MISMATCH' END AS Result
FROM @Expected e LEFT JOIN @Actual a ON a.TableName=e.TableName
ORDER BY e.TableName;
IF EXISTS (
 SELECT 1 FROM @Expected e LEFT JOIN @Actual a ON e.TableName=a.TableName
 WHERE a.ActualRows IS NULL OR a.ActualRows <> e.ExpectedRows
) THROW 51010, 'Chinook row counts do not match supplied export.', 1;
IF (SELECT is_cdc_enabled FROM sys.databases WHERE name=N'Chinook')<>1
 THROW 51011, 'Chinook database CDC is not enabled.', 1;
IF (SELECT COUNT(*) FROM sys.tables WHERE schema_id=SCHEMA_ID(N'dbo') AND is_tracked_by_cdc=1)<>11
 THROW 51012, 'CDC should be enabled on exactly 11 operational tables.', 1;
IF (SELECT is_tracked_by_cdc FROM sys.tables WHERE object_id=OBJECT_ID(N'dbo.Test'))<>0
 THROW 51013, 'Test table should not be tracked by CDC.', 1;
IF (SELECT COUNT(*) FROM sys.foreign_keys WHERE parent_object_id IN
 (SELECT object_id FROM sys.tables WHERE schema_id=SCHEMA_ID(N'dbo')))<>11
 THROW 51014, 'Expected 11 foreign keys.', 1;
IF EXISTS (
 SELECT 1 FROM dbo.InvoiceLine
 WHERE LineTotal<>CONVERT(decimal(14,2),(1-Discount)*(UnitPrice*Quantity))
 ) THROW 51015, 'InvoiceLine computed LineTotal mismatch.', 1;
SELECT N'PASS: row counts, 11 CDC tables, 11 foreign keys, LineTotal validated' AS verification;
SELECT name, is_tracked_by_cdc FROM sys.tables WHERE schema_id=SCHEMA_ID(N'dbo') ORDER BY name;
SELECT name, enabled FROM msdb.dbo.sysjobs WHERE name LIKE N'cdc.Chinook%';
GO
