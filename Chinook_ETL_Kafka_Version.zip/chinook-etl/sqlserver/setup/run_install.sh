#!/usr/bin/env bash
set -euo pipefail
# Run from within the unpacked directory in WSL:
#   bash sqlserver/setup/run_install.sh
# This script does NOT delete Docker volumes, databases, or existing containers.
SELF_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd -- "$SELF_DIR/../.." && pwd)"
cd "$PROJECT_DIR"

for file in create_schema.sql seed_data.sql foreign_keys.sql enable_cdc.sql validate_source.sql; do
  [[ -f "$SELF_DIR/$file" ]] || { echo "Missing $file in $SELF_DIR" >&2; exit 1; }
done

docker compose config -q
if ! docker compose config --services | grep -qx sqlserver; then
  echo "ERROR: Existing compose.yaml does not define a sqlserver service." >&2; exit 1
fi

echo "Starting only the existing SQL Server service (other services are unchanged)..."
docker compose up -d sqlserver
CID="$(docker compose ps -q sqlserver)"
[[ -n "$CID" ]] || { echo "SQL Server container did not start. Check 'docker compose logs sqlserver'." >&2; exit 1; }

# SQLCMDPASSWORD is read from the container's existing MSSQL_SA_PASSWORD; never echoed.
DO_SQLCMD='set -euo pipefail
if [[ -x /opt/mssql-tools18/bin/sqlcmd ]]; then
 SQLCMD=/opt/mssql-tools18/bin/sqlcmd
elif [[ -x /opt/mssql-tools/bin/sqlcmd ]]; then
 SQLCMD=/opt/mssql-tools/bin/sqlcmd
else
 echo "sqlcmd missing inside SQL Server image; use Windows SSMS to execute the SQL scripts instead." >&2
 exit 127
fi
export SQLCMDPASSWORD="${MSSQL_SA_PASSWORD:?MSSQL_SA_PASSWORD not present in container environment}"
exec "$SQLCMD" -S localhost -U sa -C -b -r1 -l 5 "$@"'

ready=0
for attempt in {1..40}; do
  if docker exec "$CID" /bin/bash -lc "$DO_SQLCMD" bash -Q 'SET NOCOUNT ON; SELECT 1;' >/dev/null 2>&1; then
    ready=1; break
  fi
  sleep 3
done
[[ $ready -eq 1 ]] || {
  echo "Cannot connect to Docker SQL Server. Check docker compose logs --tail=80 sqlserver" >&2
  exit 1
}

# DO NOT load into an existing Chinook database. This protects against accidental double inserts.
CHECK_DB=$(docker exec "$CID" /bin/bash -lc "$DO_SQLCMD" bash -h -1 -W -Q \
  "SET NOCOUNT ON; SELECT CASE WHEN DB_ID(N'Chinook') IS NULL THEN 0 ELSE 1 END;")
if [[ $(echo "$CHECK_DB" | tr -d '\\r[:space:]') != 0 ]]; then
  echo "STOP: Chinook already exists in the Docker SQL Server instance. No changes made." >&2
  echo "Inspect existing data before re-running. This installer never drops databases." >&2
  exit 1
fi

for f in \
  create_schema.sql \
  seed_data.sql \
  foreign_keys.sql \
  enable_cdc.sql \
  validate_source.sql; do
    echo "==> Running $f"
    docker exec -i "$CID" /bin/bash -lc "$DO_SQLCMD" bash -i /dev/stdin < "$SELF_DIR/$f"
done

echo 'Chinook initialization and CDC SQL scripts completed successfully.'
