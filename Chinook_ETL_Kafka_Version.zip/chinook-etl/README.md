# Chinook ETL

Data engineering course project using the Chinook database.

## Data flow

```text
SQL Server (Chinook + CDC)
  -> Kafka producer -> Kafka -> Kafka consumer
  -> PostgreSQL staging -> ClickHouse warehouse
  -> PostgreSQL reporting -> Grafana
```

The first run loads the source data with Python and Pandas. After that, SQL Server CDC
captures inserts, updates and deletes. Kafka delivers the changes to the consumer,
which updates staging and the warehouse. The reporting tables are copied from
ClickHouse to PostgreSQL because the included Grafana dashboards use PostgreSQL.

The warehouse implements Type 1 updates, Type 2 history for customers and tracks,
and logical deletion for playlist-track memberships. Kafka checkpoints are stored
in PostgreSQL so the full load does not run again after a restart.

## Run locally

Requires Ubuntu on WSL2, Docker Engine, Docker Compose v2, Python 3 and curl.
The Kafka image is built from the Apache release archive because the Docker
registry image was not accessible on this machine.

```bash
bash install.sh       # first install or resume the existing stack
bash verify.sh        # check data and services
docker compose ps     # show containers
```

Grafana: http://localhost:3000

Username: `admin`. To view the generated password:

```bash
bash secrets-help.sh
```

For recent changes:

```bash
docker compose logs --tail 30 cdc-producer cdc-consumer
```

The Grafana dashboards are **Chinook | Sales Overview** and
**Chinook | Music & Customers**.

## Notes

- The project uses Docker Compose, not Airflow or Spark.
- `.env` holds the local database and Grafana passwords. Do not commit it.
- The Docker volume names and Compose project name are fixed to keep existing data.
- The Kafka broker is configured for a local course demo, not public deployment.
- Do **not** run `docker compose down -v` or `docker volume prune` on your working project.
- Kafka and SQL Server CDC have finite retention periods; a prolonged outage may need resynchronization.
