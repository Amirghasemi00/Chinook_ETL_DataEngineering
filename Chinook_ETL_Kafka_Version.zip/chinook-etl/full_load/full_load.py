#!/usr/bin/env python3
"""Chinook initial full load: SQL Server -> PostgreSQL staging -> ClickHouse.

Runs on the WSL host using the existing local Compose ports. This is a ONE-TIME
bootstrap; freeze source writes while it runs. It is not the CDC/incremental DAG.

Safe to retry an interrupted bootstrap: keys are stable, staging is replaced,
and ReplacingMergeTree rows are reinserted with identical key+revision. Check
logical ClickHouse counts using FINAL until background merges complete.
"""
from __future__ import annotations

import os
import sys
import hashlib
import json
import logging
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import pandas as pd
import pymssql
import psycopg2
from psycopg2.extras import execute_values
import clickhouse_connect

log = logging.getLogger('chinook.full_load')
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

SOURCE = {
    'Artist': 'artist',
    'Album': 'album',
    'Genre': 'genre',
    'MediaType': 'mediatype',
    'Track': 'track',
    'Employee': 'employee',
    'Customer': 'customer',
    'Invoice': 'invoice',
    'InvoiceLine': 'invoiceline',
    'Playlist': 'playlist',
    'PlaylistTrack': 'playlisttrack',
}
# The seeded source records the user verified; a changed source is rejected on
# first load so an inadvertent test update cannot go unnoticed.
EXPECTED = {
    'artist': 275, 'album': 347, 'genre': 25, 'mediatype': 5,
    'track': 3503, 'employee': 10, 'customer': 59, 'invoice': 412,
    'invoiceline': 2240, 'playlist': 18, 'playlisttrack': 8715,
}
BUSINESS_DW = [
    'DimGeography', 'DimEmployee', 'DimCustomer', 'DimAlbum',
    'DimTrack', 'DimPlaylist', 'DimPlaylistTrack', 'FactInvoice',
]


def read_env(path: Path):
    if not path.is_file():
        raise RuntimeError(f'Missing {path}; run from the project root')
    result = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        k, v = line.split('=', 1)
        result[k] = v.strip().strip('"\'')
    return result


def cfg(env, key, default=None):
    value = os.environ.get(key, env.get(key, default))
    if value is None or value == '':
        raise RuntimeError(f'Missing setting {key}')
    return value


def py(v):
    if v is None:
        return None
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(v, pd.Timestamp):
        return v.to_pydatetime()
    if hasattr(v, 'item') and not isinstance(v, (str, bytes, Decimal, datetime)):
        return v.item()
    return v


def records(frame):
    for rec in frame.to_dict('records'):
        yield {k: py(v) for k, v in rec.items()}


def collect_sqlserver(conn):
    result = {}
    cur = conn.cursor()
    for table, dest in SOURCE.items():
        cur.execute(f'SELECT * FROM dbo.[{table}]')
        cols = [d[0].lower() for d in cur.description]
        data = cur.fetchall()
        frame = pd.DataFrame(data, columns=cols, dtype=object)
        expected = EXPECTED[dest]
        if len(frame) != expected:
            raise RuntimeError(f'dbo.{table}: {len(frame)} rows, expected {expected}; source has changed')
        result[dest] = frame
        log.info('SQL Server dbo.%-13s %5d rows', table, len(frame))
    cur.execute('SELECT COUNT(*) FROM cdc.change_tables')
    if cur.fetchone()[0] != 11:
        raise RuntimeError('CDC has not been enabled on exactly the 11 planned tables')
    return result


def pg_count(cur, table):
    cur.execute(f'SELECT COUNT(*) FROM {table}')
    return cur.fetchone()[0]


def phase_preflight(pg, ch):
    with pg.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM etl.pipeline_run WHERE load_kind='full' AND state='completed'")
        if cur.fetchone()[0]:
            raise RuntimeError('Full load already completed. Do not rerun it; next step is CDC incremental.')
        cur.execute('SELECT COUNT(*) FROM etl.cdc_checkpoint')
        if cur.fetchone()[0]:
            raise RuntimeError('CDC checkpoints already exist; will not reset an initialized pipeline')
        cur.execute('SELECT COUNT(*) FROM etl.cdc_events')
        if cur.fetchone()[0]:
            raise RuntimeError('CDC events already exist; initial load will not overwrite pending events')
        cur.execute("SELECT COUNT(*) FROM etl.pipeline_run WHERE load_kind='incremental'")
        if cur.fetchone()[0]:
            raise RuntimeError('Incremental pipeline history already exists; bootstrap is blocked')
        cur.execute("SELECT COUNT(*) FROM etl.pipeline_run WHERE load_kind='full'")
        first_attempt = cur.fetchone()[0] == 0
    if first_attempt:
        for name in BUSINESS_DW:
            n = ch.query(f'SELECT count() FROM Chinook.{name}').result_rows[0][0]
            if n:
                raise RuntimeError(f'Chinook.{name} contains {n} rows before first full load; aborting')
        if pg_count(pg.cursor(), 'etl.surrogate_key'):
            raise RuntimeError('Surrogate keys exist before first full load; aborting')
        with pg.cursor() as cur:
            for dest in SOURCE.values():
                if pg_count(cur, f'stg.{dest}'):
                    raise RuntimeError(f'stg.{dest} contains rows before first full load; aborting')
    count = ch.query('SELECT count() FROM Chinook.DimDate').result_rows[0][0]
    if count != 33238:
        raise RuntimeError(f'DimDate has {count} rows (expected 33238)')
    return first_attempt


def run_record(pg):
    with pg.cursor() as cur:
        cur.execute("SELECT run_id, started_at FROM etl.pipeline_run WHERE load_kind='full' "
                    "AND state IN ('failed','running') ORDER BY run_id LIMIT 1")
        existing = cur.fetchone()
        if existing:
            rid, started_at = existing
            cur.execute("UPDATE etl.pipeline_run SET state='running', finished_at=NULL, "
                        "notes='Bootstrap retry' WHERE run_id=%s", (rid,))
        else:
            cur.execute("INSERT INTO etl.pipeline_run (load_kind, state, notes) "
                        "VALUES ('full','running','Initial Chinook snapshot') RETURNING run_id, started_at")
            rid, started_at = cur.fetchone()
    pg.commit()
    return rid, started_at.astimezone(timezone.utc)


def stage_data(pg, raw):
    # No staging FKs: a single PostgreSQL transaction replaces just the 11
    # operational snapshot tables, never any of the etl.* control tables.
    with pg.cursor() as cur:
        cur.execute('TRUNCATE ' + ', '.join(f'stg.{t}' for t in SOURCE.values()))
        for name, frame in raw.items():
            cols = [c for c in frame.columns if c != 'linetotal']  # computed in PostgreSQL
            if len(frame) == 0:
                continue
            values = [tuple(r[c] for c in cols) for r in records(frame)]
            columns_sql = ', '.join(cols)
            execute_values(cur,
                f'INSERT INTO stg.{name} ({columns_sql}) VALUES %s',
                values, page_size=500)
            assert pg_count(cur, f'stg.{name}') == len(frame)
    pg.commit()
    log.info('PostgreSQL staging committed (%d operational records)',
             sum(len(v) for v in raw.values()))


def stage_frames(pg):
    frames = {}
    with pg.cursor() as cur:
        for dest in SOURCE.values():
            cur.execute(f'SELECT * FROM stg.{dest}')
            cols = [d[0] for d in cur.description]
            frames[dest] = pd.DataFrame(cur.fetchall(), columns=cols, dtype=object)
    return frames


def surrogate(cur, dim, alt, token='type1'):
    cur.execute('''
      INSERT INTO etl.surrogate_key (dimension_name, alternate_key, version_token)
      VALUES (%s,%s,%s)
      ON CONFLICT (dimension_name,alternate_key,version_token)
      DO UPDATE SET version_token=EXCLUDED.version_token
      RETURNING surrogate_key
    ''', (dim, str(alt), token))
    return int(cur.fetchone()[0])


def norm_geo(v):
    v = py(v)
    return v.strip() if isinstance(v, str) else v


def geo_key(row, billing=False):
    prefix = 'billing' if billing else ''
    attrs = ['address', 'city', 'state', 'country', 'postalcode']
    return tuple(norm_geo(row[prefix + a]) for a in attrs)


def date_key(value):
    value = py(value)
    if value is None:
        return None
    d = value.date() if isinstance(value, datetime) else value
    if not (datetime(1940, 1, 1).date() <= d <= datetime(2030, 12, 31).date()):
        raise RuntimeError(f'Date {d} falls outside DimDate (1940-2030)')
    return int(d.strftime('%Y%m%d'))


def make_warehouse(pg, frames, anchor):
    # Each tuple follows the existing ClickHouse table definition exactly.
    customer = list(records(frames['customer']))
    employee = list(records(frames['employee']))
    invoice = list(records(frames['invoice']))
    album_frame = frames['album'].merge(frames['artist'][['artistid','name']],
                                        on='artistid', how='left', validate='many_to_one',
                                        suffixes=('', '_artist'))
    album = list(records(album_frame))
    genre_map = {r['genreid']: r['name'] for r in records(frames['genre'])}
    media_map = {r['mediatypeid']: r['name'] for r in records(frames['mediatype'])}
    playlist = list(records(frames['playlist']))
    track = list(records(frames['track']))
    pltrack = list(records(frames['playlisttrack']))
    invline = list(records(frames['invoiceline']))
    invoices_by_id = {r['invoiceid']: r for r in invoice}
    with pg.cursor() as cur:
        geo_map = {}
        geo_rows = []
        # UNION ALL of Customer/Employee/Invoice followed by DISTINCT is the
        # user's approved geography source. Nulls are compared as equal.
        geo_set = set()
        for r in customer + employee:
            geo_set.add(geo_key(r))
        for r in invoice:
            geo_set.add(geo_key(r, billing=True))
        for attrs in sorted(geo_set, key=lambda x: tuple('' if a is None else str(a) for a in x)):
            if all(a is None for a in attrs):
                continue
            token = hashlib.sha256(json.dumps(attrs, ensure_ascii=False).encode()).hexdigest()
            k = surrogate(cur, 'DimGeography', token)
            geo_map[attrs] = k
            geo_rows.append((k, *attrs, 1))
        def find_geo(r, billing=False):
            return geo_map.get(geo_key(r,billing))

        employee_map = {r['employeeid']: surrogate(cur,'DimEmployee',r['employeeid']) for r in employee}
        album_map = {r['albumid']: surrogate(cur,'DimAlbum',r['albumid']) for r in album}
        playlist_map = {r['playlistid']: surrogate(cur,'DimPlaylist',r['playlistid']) for r in playlist}
        customer_map = {r['customerid']: surrogate(cur,'DimCustomer',r['customerid'],'initial') for r in customer}
        track_map = {r['trackid']: surrogate(cur,'DimTrack',r['trackid'],'initial') for r in track}

        employee_rows = []
        for r in employee:
            employee_rows.append((employee_map[r['employeeid']], r['employeeid'], r['lastname'],
                r['firstname'], r['title'], employee_map.get(r['reportsto']),
                date_key(r['birthdate']), date_key(r['hiredate']), find_geo(r),
                r['phone'], r['fax'], r['email'], r['department'], r['salary'], 1))

        customer_rows = []
        for r in customer:
            customer_rows.append((customer_map[r['customerid']], r['customerid'], r['firstname'],
                r['lastname'], r['company'], r['phone'], r['fax'], r['email'],
                find_geo(r), employee_map.get(r['supportrepid']), anchor, None, 1, 1))

        album_rows = []
        for r in album:
            album_rows.append((album_map[r['albumid']], r['albumid'], r['title'], r['name'], 1))

        track_rows = []
        for r in track:
            track_rows.append((track_map[r['trackid']], r['trackid'], r['name'],
                album_map.get(r['albumid']), genre_map.get(r['genreid']),
                media_map.get(r['mediatypeid']), r['composer'], r['milliseconds'],
                r['bytes'], r['unitprice'], anchor, None, 1, 1))

        playlist_rows = [(playlist_map[r['playlistid']], r['playlistid'], r['name'], 1)
                         for r in playlist]
        bridge_rows = [(playlist_map[r['playlistid']], track_map[r['trackid']], 1, 1)
                       for r in pltrack]

        fact_rows = []
        for line in invline:
            iv = invoices_by_id[line['invoiceid']]
            amount = line['linetotal']
            # The PostgreSQL computed column enforces the same formula
            # that was validated in SQL Server.
            fact_rows.append((line['invoicelineid'], line['invoiceid'],
                customer_map[iv['customerid']], track_map[line['trackid']],
                find_geo(iv, True), date_key(iv['invoicedate']),
                line['unitprice'], line['quantity'], line['discount'], amount, 0, 1))
    pg.commit()
    return {
      'DimGeography': (['GeographyKey','Address','City','State','Country','PostalCode','Revision'], geo_rows),
      'DimEmployee': (['EmployeeKey','EmployeeAlternateKey','LastName','FirstName','Title',
                      'ReportsToKey','BirthDateKey','HireDateKey','GeographyKey','Phone','Fax',
                      'Email','Department','Salary','Revision'], employee_rows),
      'DimAlbum': (['AlbumKey','AlbumAlternateKey','Title','ArtistName','Revision'], album_rows),
      'DimCustomer': (['CustomerKey','CustomerAlternateKey','FirstName','LastName','Company',
                      'Phone','Fax','Email','GeographyKey','SupportRepKey','ValidFrom',
                      'ValidTo','IsCurrent','Revision'], customer_rows),
      'DimTrack': (['TrackKey','TrackAlternateKey','Name','AlbumKey','GenreName','MediaTypeName',
                   'Composer','Milliseconds','Bytes','UnitPrice','ValidFrom','ValidTo',
                   'IsCurrent','Revision'], track_rows),
      'DimPlaylist': (['PlaylistKey','PlaylistAlternateKey','Name','Revision'], playlist_rows),
      'DimPlaylistTrack': (['PlaylistKey','TrackKey','IsActive','Revision'], bridge_rows),
      'FactInvoice': (['InvoiceLineId','InvoiceId','CustomerKey','TrackKey','GeographyKey',
                      'InvoiceDateKey','UnitPrice','Quantity','Discount','LineTotal',
                      'IsDeleted','Revision'], fact_rows),
    }


def insert_warehouse(ch, transformed):
    for name, (columns, values) in transformed.items():
        log.info('ClickHouse %-18s %5d rows', name, len(values))
        for start in range(0, len(values), 1000):
            ch.insert('Chinook.'+name, values[start:start+1000], column_names=columns)
    log.info('Warehouse initial rows inserted')


def validate_warehouse(pg, ch, raw):
    assert ch.query('SELECT count() FROM Chinook.DimDate').result_rows[0][0] == 33238
    checks = {
        'DimEmployee': 'employee', 'DimCustomer': 'customer',
        'DimAlbum': 'album', 'DimTrack': 'track', 'DimPlaylist': 'playlist',
        'DimPlaylistTrack': 'playlisttrack', 'FactInvoice': 'invoiceline',
    }
    for table, src in checks.items():
        # ReplacingMergeTree deduplicates asynchronously: FINAL reads the
        # authoritative current logical rows on a retry or before merges.
        count = ch.query(f'SELECT count() FROM Chinook.{table} FINAL').result_rows[0][0]
        expect = len(raw[src])
        if count != expect:
            raise RuntimeError(f'DW {table}: {count} logical rows, expected {expect}')
        log.info('VALIDATED %-18s %5d logical rows', table, count)
    geo_count = ch.query('SELECT count() FROM Chinook.DimGeography FINAL').result_rows[0][0]
    if geo_count < 1:
        raise RuntimeError('DimGeography is empty')
    log.info('VALIDATED DimGeography %d unique address combinations', geo_count)
    # Invoice totals are not stored in the fact, by design. Validate the
    # total of invoice LINE values against source invoice line sums instead.
    dw_total = Decimal(str(ch.query('SELECT sum(LineTotal) FROM Chinook.FactInvoice FINAL').result_rows[0][0]))
    source_total = sum((r['linetotal'] for r in records(stage_frames(pg)['invoiceline'])), Decimal('0'))
    if abs(dw_total - source_total) > Decimal('0.01'):
        raise RuntimeError(f'Fact LineTotal mismatch: DW {dw_total} != staging {source_total}')
    log.info('VALIDATED FactInvoice total LineTotal = %s', dw_total)


def initialize_checkpoints(pg, source):
    # Bootstrap assumption: the user must not change operational Chinook
    # while initial data is extracted and the DW is built. The checkpoint is
    # the current high-water LSN only AFTER a validated full load.
    c = source.cursor()
    c.execute('SELECT sys.fn_cdc_get_max_lsn()')
    lsn = c.fetchone()[0]
    if isinstance(lsn, memoryview):
        lsn = lsn.tobytes()
    if lsn is None or not isinstance(lsn, (bytes, bytearray)) or len(lsn) != 10:
        raise RuntimeError(f'Invalid CDC max LSN: {lsn!r}; no checkpoints written')
    c.execute('SELECT capture_instance FROM cdc.change_tables ORDER BY capture_instance')
    instances = [x[0] for x in c.fetchall()]
    if len(instances) != 11:
        raise RuntimeError('CDC capture instance count changed during full load')
    with pg.cursor() as cur:
        for inst in instances:
            cur.execute('''
              INSERT INTO etl.cdc_checkpoint(capture_instance,last_lsn)
              VALUES (%s,%s)
              ON CONFLICT (capture_instance) DO NOTHING
            ''', (inst, psycopg2.Binary(bytes(lsn))))
    log.info('Prepared 11 CDC checkpoints at LSN %s', bytes(lsn).hex())


def main():
    root = Path(__file__).resolve().parent.parent
    if not (root / 'compose.yaml').exists():
        raise RuntimeError('Place the full_load folder directly inside the project root')
    env = read_env(root / '.env')
    mssql = pymssql.connect(server=cfg(env,'SQLSERVER_HOST','127.0.0.1'),
                            port=int(cfg(env,'SQLSERVER_PORT','1433')),
                            user='sa', password=cfg(env,'MSSQL_SA_PASSWORD'),
                            database='Chinook', charset='UTF-8', login_timeout=20,
                            timeout=120)
    mssql.autocommit(True)  # avoid holding a read transaction across the warehouse load
    pg = psycopg2.connect(host=cfg(env,'STAGING_HOST','127.0.0.1'),
                         port=int(cfg(env,'STAGING_PORT','5432')),
                         dbname='chinook_staging', user='etl_user',
                         password=cfg(env,'POSTGRES_PASSWORD'), connect_timeout=20)
    ch = clickhouse_connect.get_client(host=cfg(env,'DW_HOST','127.0.0.1'),
        port=int(cfg(env,'DW_PORT','8123')), username='etl_user',
        password=cfg(env,'CLICKHOUSE_PASSWORD'), database='Chinook',
        connect_timeout=15, send_receive_timeout=120)
    rid = None
    try:
        first_attempt = phase_preflight(pg, ch)
        log.info('Bootstrap mode: %s', 'first run' if first_attempt else 'retry incomplete run')
        rid, anchor = run_record(pg)
        raw = collect_sqlserver(mssql)
        stage_data(pg, raw)
        frame = stage_frames(pg)
        transformed = make_warehouse(pg, frame, anchor)
        insert_warehouse(ch, transformed)
        validate_warehouse(pg, ch, raw)
        initialize_checkpoints(pg, mssql)
        with pg.cursor() as cur:
            cur.execute("UPDATE etl.pipeline_run SET state='completed', finished_at=now(), "
                        "notes='Initial load and logical DW checks passed' WHERE run_id=%s",(rid,))
        pg.commit()
        log.info('SUCCESS: Initial full load completed; CDC checkpoints persisted. Source Chinook unchanged.')
    except Exception:
        pg.rollback()
        if rid is not None:
            try:
                with pg.cursor() as cur:
                    cur.execute("UPDATE etl.pipeline_run SET state='failed', finished_at=now(), "
                                "notes='Full load failed (inspect terminal output)' WHERE run_id=%s",(rid,))
                pg.commit()
            except Exception:
                pg.rollback()
        log.exception('FAILED: bootstrap did not complete; do not run incremental ETL yet')
        sys.exit(1)
    finally:
        ch.close()
        pg.close()
        mssql.close()


if __name__ == '__main__':
    main()
