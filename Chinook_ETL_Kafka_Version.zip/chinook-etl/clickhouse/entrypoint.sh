#!/usr/bin/env bash
set -Eeuo pipefail

: "${CLICKHOUSE_USER:?CLICKHOUSE_USER must be set}"
: "${CLICKHOUSE_PASSWORD:?CLICKHOUSE_PASSWORD must be set}"

# Usernames are XML element names; reject special characters and markup.
if ! [[ "$CLICKHOUSE_USER" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]]; then
  echo "Invalid CLICKHOUSE_USER: letters, numbers, underscores only" >&2
  exit 1
fi

# Hash prevents writing the plaintext password into ClickHouse XML.
password_hash="$(printf '%s' "$CLICKHOUSE_PASSWORD" | sha256sum | cut -d' ' -f1)"
cat > /etc/clickhouse-server/users.d/chinook-etl-user.xml <<XML
<clickhouse>
  <users>
    <default remove="remove"/>
    <${CLICKHOUSE_USER}>
      <password_sha256_hex>${password_hash}</password_sha256_hex>
      <networks><ip>0.0.0.0/0</ip></networks>
      <profile>default</profile>
      <quota>default</quota>
      <access_management>1</access_management>
    </${CLICKHOUSE_USER}>
  </users>
</clickhouse>
XML
chmod 644 /etc/clickhouse-server/users.d/chinook-etl-user.xml

mkdir -p /var/lib/clickhouse /var/log/clickhouse-server
chown -R clickhouse:clickhouse /var/lib/clickhouse /var/log/clickhouse-server

# Database setup creates the Chinook warehouse tables.
# This process replaces PID 1 and handles signals correctly.
exec clickhouse su clickhouse:clickhouse clickhouse-server --config-file=/etc/clickhouse-server/config.xml
