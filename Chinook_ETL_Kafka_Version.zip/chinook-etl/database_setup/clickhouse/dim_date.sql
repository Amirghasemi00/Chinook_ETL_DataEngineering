-- Adapted from user's dw_load_dim_date.sql.
-- Only database/table naming and lower bound change; original 10 attributes remain.
-- Date32 is REQUIRED for employee birthdays before 1970; Date would not represent them.
-- Load once (the installer checks that the calendar table is empty).
INSERT INTO Chinook.DimDate
    (DateKey, FullDate, Year, Quarter, Month, MonthName,
     DayOfMonth, DayOfWeek, DayName, IsWeekend)
SELECT
    toUInt32(toYYYYMMDD(d)) AS DateKey,
    d AS FullDate,
    toUInt16(toYear(d)) AS Year,
    toUInt8(toQuarter(d)) AS Quarter,
    toUInt8(toMonth(d)) AS Month,
    multiIf(
      toMonth(d) = 1, 'January', toMonth(d) = 2, 'February',
      toMonth(d) = 3, 'March', toMonth(d) = 4, 'April',
      toMonth(d) = 5, 'May', toMonth(d) = 6, 'June',
      toMonth(d) = 7, 'July', toMonth(d) = 8, 'August',
      toMonth(d) = 9, 'September', toMonth(d) = 10, 'October',
      toMonth(d) = 11, 'November', 'December') AS MonthName,
    toUInt8(toDayOfMonth(d)) AS DayOfMonth,
    toUInt8(toDayOfWeek(d)) AS DayOfWeek,
    multiIf(
      toDayOfWeek(d) = 1, 'Monday', toDayOfWeek(d) = 2, 'Tuesday',
      toDayOfWeek(d) = 3, 'Wednesday', toDayOfWeek(d) = 4, 'Thursday',
      toDayOfWeek(d) = 5, 'Friday', toDayOfWeek(d) = 6, 'Saturday',
      'Sunday') AS DayName,
    toUInt8(if(toDayOfWeek(d) IN (6, 7), 1, 0)) AS IsWeekend
FROM (
    SELECT addDays(toDate32('1940-01-01'), toInt32(number)) AS d
    FROM numbers(dateDiff('day', toDate32('1940-01-01'), toDate32('2030-12-31')) + 1)
);
