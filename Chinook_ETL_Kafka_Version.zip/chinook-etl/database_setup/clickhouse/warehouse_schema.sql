-- Chinook DW | ClickHouse 25.8 | 7 dimensions, 1 bridge, 1 fact.
-- Logical foreign keys are intentionally not enforced by ClickHouse.
-- ReplacingMergeTree requires FINAL (or equivalent latest-row logic) for current reads.
CREATE DATABASE IF NOT EXISTS Chinook;

CREATE TABLE IF NOT EXISTS Chinook.DimDate (
    DateKey UInt32,
    FullDate Date32,
    Year UInt16,
    Quarter UInt8,
    Month UInt8,
    MonthName String,
    DayOfMonth UInt8,
    DayOfWeek UInt8,
    DayName String,
    IsWeekend UInt8
) ENGINE = MergeTree ORDER BY DateKey;

CREATE TABLE IF NOT EXISTS Chinook.DimGeography (
    GeographyKey UInt64,
    Address Nullable(String),
    City Nullable(String),
    State Nullable(String),
    Country Nullable(String),
    PostalCode Nullable(String),
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY GeographyKey;

CREATE TABLE IF NOT EXISTS Chinook.DimEmployee (
    EmployeeKey UInt64,
    EmployeeAlternateKey Int32,
    LastName String,
    FirstName String,
    Title Nullable(String),
    ReportsToKey Nullable(UInt64),
    BirthDateKey Nullable(UInt32),
    HireDateKey Nullable(UInt32),
    GeographyKey Nullable(UInt64),
    Phone Nullable(String),
    Fax Nullable(String),
    Email Nullable(String),
    Department Nullable(String),
    Salary Decimal(19,4),
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY EmployeeKey;

CREATE TABLE IF NOT EXISTS Chinook.DimCustomer (
    CustomerKey UInt64,
    CustomerAlternateKey Int32,
    FirstName String,
    LastName String,
    Company Nullable(String),
    Phone Nullable(String),
    Fax Nullable(String),
    Email String,
    GeographyKey Nullable(UInt64),
    SupportRepKey Nullable(UInt64),
    ValidFrom DateTime64(3, 'UTC'),
    ValidTo Nullable(DateTime64(3, 'UTC')),
    IsCurrent UInt8,
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY CustomerKey;

CREATE TABLE IF NOT EXISTS Chinook.DimAlbum (
    AlbumKey UInt64,
    AlbumAlternateKey Int32,
    Title String,
    ArtistName Nullable(String),
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY AlbumKey;

CREATE TABLE IF NOT EXISTS Chinook.DimTrack (
    TrackKey UInt64,
    TrackAlternateKey Int32,
    Name String,
    AlbumKey Nullable(UInt64),
    GenreName Nullable(String),
    MediaTypeName Nullable(String),
    Composer Nullable(String),
    Milliseconds Int32,
    Bytes Nullable(Int32),
    UnitPrice Decimal(10,2),
    ValidFrom DateTime64(3, 'UTC'),
    ValidTo Nullable(DateTime64(3, 'UTC')),
    IsCurrent UInt8,
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY TrackKey;

CREATE TABLE IF NOT EXISTS Chinook.DimPlaylist (
    PlaylistKey UInt64,
    PlaylistAlternateKey Int32,
    Name Nullable(String),
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY PlaylistKey;

-- The PlaylistTrack relationship is a bridge; updates can toggle IsActive=0.
CREATE TABLE IF NOT EXISTS Chinook.DimPlaylistTrack (
    PlaylistKey UInt64,
    TrackKey UInt64,
    IsActive UInt8,
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY (PlaylistKey, TrackKey);

-- Fact grain: one InvoiceLineId. InvoiceTotal intentionally excluded.
CREATE TABLE IF NOT EXISTS Chinook.FactInvoice (
    InvoiceLineId Int32,
    InvoiceId Int32,
    CustomerKey UInt64,
    TrackKey UInt64,
    GeographyKey Nullable(UInt64),
    InvoiceDateKey UInt32,
    UnitPrice Decimal(10,2),
    Quantity Int32,
    Discount Decimal(5,2),
    LineTotal Decimal(14,2),
    IsDeleted UInt8,
    Revision UInt64
) ENGINE = ReplacingMergeTree(Revision) ORDER BY InvoiceLineId;

SELECT name, engine FROM system.tables
WHERE database = 'Chinook' AND name NOT LIKE '.inner%'
ORDER BY name;
